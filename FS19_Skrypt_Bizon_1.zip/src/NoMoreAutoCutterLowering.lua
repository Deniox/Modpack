-- @author      Templeton Peck
-- @date        2020-03-29
-- @version     1.0.1.0

NoMoreAutoCutterLowering = {};
  
function NoMoreAutoCutterLowering.prerequisitesPresent(specializations)
	return true
end

function NoMoreAutoCutterLowering.registerOverwrittenFunctions(vehicleType)
    SpecializationUtil.registerOverwrittenFunction(vehicleType, "startThreshing", NoMoreAutoCutterLowering.startThreshing)
	SpecializationUtil.registerOverwrittenFunction(vehicleType, "stopThreshing", NoMoreAutoCutterLowering.stopThreshing)
end

function NoMoreAutoCutterLowering:startThreshing()
	local spec = self.spec_combine

    if spec.numAttachedCutters > 0 then
		for _,cutter in pairs(spec.attachedCutters) do
			cutter:setIsTurnedOn(true, true)
		end
		
        if spec.threshingStartAnimation ~= nil and self.playAnimation ~= nil then
            self:playAnimation(spec.threshingStartAnimation, spec.threshingStartAnimationSpeedScale, self:getAnimationTime(spec.threshingStartAnimation), true)
		end
		
        if self.isClient then
            g_soundManager:stopSamples(spec.samples)
            g_soundManager:playSample(spec.samples.start)
            g_soundManager:playSample(spec.samples.work, 0, spec.samples.start)
		end
		
        SpecializationUtil.raiseEvent(self, "onStartThreshing")
    end
end
	
function NoMoreAutoCutterLowering:stopThreshing()
	local spec = self.spec_combine

    if self.isClient then
        g_soundManager:stopSamples(spec.samples)
        g_soundManager:playSample(spec.samples.stop)
	end
	
	self:setCombineIsFilling(false, false, true)
	
    for cutter,_ in pairs(spec.attachedCutters) do
        cutter:setIsTurnedOn(false, true)
    end
	
    if spec.threshingStartAnimation ~= nil and spec.playAnimation ~= nil then
        self:playAnimation(spec.threshingStartAnimation, -spec.threshingStartAnimationSpeedScale, self:getAnimationTime(spec.threshingStartAnimation), true)
	end
	
    SpecializationUtil.raiseEvent(self, "onStopThreshing")
end
