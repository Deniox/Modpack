-- @author      Templeton Peck
-- @date        2020-03-29
-- @version     1.0.1.0

local specName = 'noMoreAutoCutterLowering'

g_specializationManager:addSpecialization(specName, 'NoMoreAutoCutterLowering', Utils.getFilename('src/NoMoreAutoCutterLowering.lua', g_currentModDirectory), nil)

for typeName, typeEntry in pairs(g_vehicleTypeManager:getVehicleTypes()) do
	if (typeName == 'combineDrivable' or typeName == 'pdlc_claasPack.combineDrivableCrawlers') then
		g_vehicleTypeManager:addSpecialization(typeName, g_currentModName .. "." .. specName)
	end
-- g_vehicleTypeManager:addSpecialization('cottonHarvester', g_currentModName .. "." .. specName)
end