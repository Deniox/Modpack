-- ============================================================= --
-- EMPTY BALER EVENT
-- ============================================================= --
EmptyBalerEvent = {}
EmptyBalerEvent_mt = Class(EmptyBalerEvent, Event)

InitEventClass(EmptyBalerEvent, "EmptyBalerEvent")

print("EmptyBalerEvent INITIALISED")

function EmptyBalerEvent:emptyNew()
	--print("EmptyBalerEvent - EMPTY NEW")
	local self =  Event:new(EmptyBalerEvent_mt)
	return self
end

function EmptyBalerEvent:new(object)
	print("EmptyBalerEvent - NEW")
	local self = EmptyBalerEvent:emptyNew()
	self.object = object
	
	return self
end

function EmptyBalerEvent:readStream(streamId, connection)
	print("EmptyBalerEvent - READ STREAM")
	self.object = NetworkUtil.readNodeObject(streamId)
	self:run(connection)
end

function EmptyBalerEvent:writeStream(streamId, connection)
	print("EmptyBalerEvent - WRITE STREAM")
	NetworkUtil.writeNodeObject(streamId, self.object)
end

function EmptyBalerEvent:run(connection)
	print("EmptyBalerEvent - RUN")
end

function EmptyBalerEvent:sendEvent(object)
	print("EmptyBalerEvent - SEND EVENT")
	if g_server ~= nil then
		--print("EmptyBalerEvent SERVER")
		--g_server:broadcastEvent(EmptyBalerEvent:new(object))
	else
		print("EmptyBalerEvent CLIENT")
		g_client:getServerConnection():sendEvent(EmptyBalerEvent:new(object))
	end
end

