--
-- FS19 - Vehicle Straps
-- @author:    	kenny456 (kenny456@seznam.cz)
-- @history:	v1.0.0.0 - 2020-11-25 - first release
--
VehicleStraps = {}
VehicleStraps.confDir = getUserProfileAppPath().. "modsSettings/VehicleStraps/"
VehicleStraps.modDirectory = g_currentModDirectory
VehicleStraps.vehicles = {}
VehicleStraps.showHelp = true

function VehicleStraps.prerequisitesPresent(specializations)
	return true
end
function VehicleStraps.registerOverwrittenFunctions(vehicleType)
	SpecializationUtil.registerOverwrittenFunction(vehicleType, "dynamicMountTriggerCallback", VehicleStraps.dynamicMountTriggerCallback)
end
function VehicleStraps.registerFunctions(vehicleType)
	SpecializationUtil.registerFunction(vehicleType, "fastenVehicles", 						VehicleStraps.fastenVehicles)
	SpecializationUtil.registerFunction(vehicleType, "unfastenVehicles", 					VehicleStraps.unfastenVehicles)
	SpecializationUtil.registerFunction(vehicleType, "createWheelChocks", 					VehicleStraps.createWheelChocks)
	SpecializationUtil.registerFunction(vehicleType, "setWheelChocksPosition", 				VehicleStraps.setWheelChocksPosition)
	if not SpecializationUtil.hasSpecialization(DynamicMountAttacher, vehicleType.specializations) then
		SpecializationUtil.registerFunction(vehicleType, "dynamicMountTriggerCallback", 	VehicleStraps.dynamicMountTriggerCallback)
	end
end
function VehicleStraps:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	if spec.event_IDs == nil then
		spec.event_IDs = {}
	else
		self:clearActionEventsTable(spec.event_IDs)
	end
	if self:getIsActiveForInput() or (self.getIscontrolled ~= nil and self:getIsControlled()) then
		if g_dedicatedServerInfo ~= nil then
			return
		end
		local actions = { InputAction.VEHICLE_STRAPS_TOGGLE_ATTACH }
		for _,actionName in pairs(actions) do
			local always = (actionName == InputAction.WORKRPM_MOVE_HUD_TRIGGER) and true or false
			local _, eventID = g_inputBinding:registerActionEvent(actionName, self, VehicleStraps.actionCallback, true, true, always, true)
			spec.event_IDs[actionName] = eventID
			if g_inputBinding ~= nil and g_inputBinding.events ~= nil and g_inputBinding.events[eventID] ~= nil then
				if actionName == 'something with lower priority' then
					g_inputBinding:setActionEventTextPriority(eventID, GS_PRIO_NORMAL)
				else
					g_inputBinding:setActionEventTextPriority(eventID, GS_PRIO_VERY_HIGH)
				end
				g_inputBinding:setActionEventTextVisibility(eventID, VehicleStraps.showHelp)
			end
			local colliding = false
			_, colliding, _ = g_inputBinding:checkEventCollision(actionName)
			if colliding then
				if g_inputBinding.nameActions[actionName].bindings[1] ~= nil then
					if g_inputBinding.nameActions[actionName].bindings[1].inputString ~= nil then
						print(string.format('Warning: VehicleStraps got a colliding input action: %s', actionName)..' ('..g_inputBinding.nameActions[actionName].bindings[1].inputString..'). You can remap it in controls settings')
					end
				else
					print(string.format('Warning: VehicleStraps got a colliding input action: %s', actionName))
				end
			end
		end
	end
end
function VehicleStraps.registerEventListeners(vehicleType)
	for _,n in pairs( { "onLoad", "onPostLoad", "onDelete", "saveToXMLFile", "onUpdate", "onUpdateTick", "onDraw", "onReadStream", "onWriteStream", "onRegisterActionEvents", "fastenVehicles", "unfastenVehicles", "createWheelChocks" } ) do
		SpecializationUtil.registerEventListener(vehicleType, n, VehicleStraps)
	end
end
function VehicleStraps:onLoad(savegame)
	self.spec_vehicleStraps = {}
	local spec = self.spec_vehicleStraps
	
	spec.modInitialized = false
	spec.modAllowed = true
	if self:getFullName() == 'Lizard Prancha Agricola' then
		spec.dynamicMountTrigger = I3DUtil.indexToObject(self.components, '0>3')
	elseif self:getFullName() == 'Lizard Beaver 20 XPT' then
		spec.dynamicMountTrigger = I3DUtil.indexToObject(self.components, '0>0|3')
	else
		spec.dynamicMountTrigger = I3DUtil.indexToObject(self.components, getXMLString(self.xmlFile, "vehicle.dynamicMountAttacher#triggerNode"), self.i3dMappings)
	end
	if spec.dynamicMountTrigger == nil then
		spec.dynamicMountTrigger = I3DUtil.indexToObject(self.components, self.i3dMappings.dynamicMountTrigger)
	end
	if spec.dynamicMountTrigger ~= nil then
		if self.spec_dynamicMountAttacher ~= nil and self.spec_dynamicMountAttacher.dynamicMountAttacherTrigger ~= nil then
			spec.modInitialized = true
		else
			local attacherTriggerTriggerNode = spec.dynamicMountTrigger
			local attacherTriggerRootNode = I3DUtil.indexToObject(self.components, Utils.getNoNil(getXMLString(self.xmlFile, "vehicle.dynamicMountAttacher#rootNode"), '0>'), self.i3dMappings)
			local attacherTriggerJointNode = I3DUtil.indexToObject(self.components, Utils.getNoNil(getXMLString(self.xmlFile, "vehicle.dynamicMountAttacher#jointNode"), '0>'), self.i3dMappings)
			if attacherTriggerTriggerNode ~= nil and attacherTriggerRootNode ~= nil and attacherTriggerJointNode ~= nil and getRigidBodyType(attacherTriggerTriggerNode) ~= 'NoRigidBody' then
				local forceAcceleration = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.dynamicMountAttacher#forceAcceleration"), 30)
				addTrigger(attacherTriggerTriggerNode, "dynamicMountTriggerCallback", self)
				local mountTypeString = Utils.getNoNil(getXMLString(self.xmlFile, "vehicle.dynamicMountAttacher#mountType"), "TYPE_AUTO_ATTACH_XZ")
				local mountType = Utils.getNoNil(DynamicMountUtil[mountTypeString], DynamicMountUtil.TYPE_AUTO_ATTACH_XZ)
				spec.dynamicMountTrigger = attacherTriggerTriggerNode
				spec.modInitialized = true
			end
		end
	end
	if not spec.modInitialized then
		--print("Error: VehicleStraps initialization failed for "..tostring(self:getFullName()).." ! "..tostring(SpecializationUtil.hasSpecialization(DynamicMountAttacher, self.specializations)))
		return
	else
		--print("VEHICLESTRAPS initialized for "..tostring(self:getFullName()).." ! "..tostring(SpecializationUtil.hasSpecialization(DynamicMountAttacher, self.specializations)))
	end
	if getCollisionMask(spec.dynamicMountTrigger) ~= 83894272 then
		setCollisionMask(spec.dynamicMountTrigger, 83894272)
	end
	spec.vehicles = {}
	spec.fastened = false
	spec.id = #VehicleStraps.vehicles + 1
	VehicleStraps.vehicles[spec.id] = self
	spec.vehicleStrapsCount = 0
	spec.vehicleStrapsMass = 0
	spec.wheelChocks = {}
	spec.timerPost = 0
end
function VehicleStraps:onPostLoad(savegame)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	if savegame ~= nil then
		local xmlFile = savegame.xmlFile
		local key = savegame.key ..".VehicleStraps"
		local fastened = Utils.getNoNil(getXMLBool(xmlFile, key.."#fastened"), spec.fastened)
		if fastened then
			spec.postFasten = true
		end
	end
end
function VehicleStraps:onDelete()
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	self:unfastenVehicles(false)
	if spec.dynamicMountTrigger ~= nil then
        removeTrigger(spec.dynamicMountTrigger)
    end
end
function VehicleStraps:saveToXMLFile(xmlFile, key)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	setXMLBool(xmlFile, key.."#fastened", spec.fastened)
end
function VehicleStraps:onUpdate(dt)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end

	if spec.postFasten then
		spec.timerPost = spec.timerPost + dt
		if spec.timerPost > 500 then
			spec.timerPost = 0
			spec.postFasten = false
			if self.isServer then
				self:fastenVehicles(false)
			elseif self.isClient and g_dedicatedServerInfo == nil then
				self:unfastenVehicles(false)
				self:fastenVehicles(false)
			end
		end
	end
	local count = 0
	spec.vehicleStrapsCount = 0
	spec.vehicleStrapsMass = 0
	for _, vehicle in pairs(spec.vehicles) do
		if vehicle ~= nil then
			local isAttachedImplement = vehicle.id.spec_attachable ~= nil and vehicle.id.spec_attachable.attacherVehicle ~= nil and vehicle.fastened == false and true or false
			local isSelfAttacher = vehicle.id == self:getRootVehicle() or (self.spec_attachable ~= nil and self.spec_attachable.attacherVehicle == vehicle.id) and true or false
			if not isAttachedImplement and not isSelfAttacher then
				count = count + 1
			end
			if vehicle.fastened then
				spec.vehicleStrapsCount = spec.vehicleStrapsCount + 1
				spec.vehicleStrapsMass = spec.vehicleStrapsMass + vehicle.id:getTotalMass(false)
			end
			if not entityExists(vehicle.id.rootNode) then
				if vehicle.fastened and self.isServer then
					removeJoint(vehicle.joint)
					vehicle.joint = nil
				end	
				spec.vehicles[vehicle.id] = nil
			end
		end
	end
	local anyVehicleInRange = count > 0 and true or false
	spec.fastened = spec.vehicleStrapsCount > 0 and true or false
	if self:getIsActiveForInput() then
		if not spec.fastened then
			if spec.input_fasten then
				spec.input_fasten = false
				self:fastenVehicles(false)
			end
		else
			if spec.input_fasten then
				spec.input_fasten = false
				self:unfastenVehicles(false)
			end
		end
	end
	--[[if self:getIsActive() then
		spec.infoText = ''
		spec.infoText = spec.infoText .. spec.id..' - '..self:getFullName()..'\n-----------------\n'
		for _, vehicle in pairs(spec.vehicles) do
			spec.infoText = spec.infoText .. vehicle.id:getFullName()..', '..vehicle.id:getTotalMass(false)..'\n'
		end
		renderText(0.7, 0.97, 0.015, spec.infoText)
	end]]
	--[[if anyVehicleInRange then
		for _, vehicle in pairs(spec.vehicles) do
			local source = vehicle.id.rootNode
			if source ~= nil and entityExists(source) then
				local x,y,z = getWorldTranslation(source)
				local nx, ny, nz = localDirectionToWorld(source, 3, 0, 0)
				local yx, yy, yz = localDirectionToWorld(source, 0, 3, 0)
				local zx, zy, zz = localDirectionToWorld(source, 0, 0, 3)
				drawDebugLine(x,y,z, 1, 0, 0, x + nx, y + ny, z + nz, 1, 0, 0);
				drawDebugLine(x,y,z, 0, 1, 0, x + yx, y + yy, z + yz, 0, 1, 0);
				drawDebugLine(x,y,z, 0, 0, 1, x + zx, y + zy, z + zz, 0, 0, 1);
			end
			local source = vehicle.transform
			if source ~= nil and entityExists(source) then
				local x,y,z = getWorldTranslation(source)
				local nx, ny, nz = localDirectionToWorld(source, 5, 0, 0)
				local yx, yy, yz = localDirectionToWorld(source, 0, 5, 0)
				local zx, zy, zz = localDirectionToWorld(source, 0, 0, 5)
				drawDebugLine(x,y,z, 1, 0, 0, x + nx, y + ny, z + nz, 1, 0, 0);
				drawDebugLine(x,y,z, 0, 1, 0, x + yx, y + yy, z + yz, 0, 1, 0);
				drawDebugLine(x,y,z, 0, 0, 1, x + zx, y + zy, z + zz, 0, 0, 1);
			end
		end
	end]]
	--[[for _, chock in pairs(spec.wheelChocks) do
		local source = chock.node
		if source ~= nil and entityExists(source) then
			local x,y,z = getWorldTranslation(source)
			local nx, ny, nz = localDirectionToWorld(source, 2, 0, 0)
			local yx, yy, yz = localDirectionToWorld(source, 0, 2, 0)
			local zx, zy, zz = localDirectionToWorld(source, 0, 0, 2)
			drawDebugLine(x,y,z, 1, 0, 0, x + nx, y + ny, z + nz, 1, 0, 0);
			drawDebugLine(x,y,z, 0, 1, 0, x + yx, y + yy, z + yz, 0, 1, 0);
			drawDebugLine(x,y,z, 0, 0, 1, x + zx, y + zy, z + zz, 0, 0, 1);
		end
		local source = chock.wheel.node
		if source ~= nil and entityExists(source) then
			local x,y,z = getWorldTranslation(source)
			local nx, ny, nz = localDirectionToWorld(source, 3, 0, 0)
			local yx, yy, yz = localDirectionToWorld(source, 0, 3, 0)
			local zx, zy, zz = localDirectionToWorld(source, 0, 0, 3)
			drawDebugLine(x,y,z, 1, 0, 0, x + nx, y + ny, z + nz, 1, 0, 0);
			drawDebugLine(x,y,z, 0, 1, 0, x + yx, y + yy, z + yz, 0, 1, 0);
			drawDebugLine(x,y,z, 0, 0, 1, x + zx, y + zy, z + zz, 0, 0, 1);
		end
		local source = chock.wheel.repr
		if source ~= nil and entityExists(source) then
			local x,y,z = getWorldTranslation(source)
			local nx, ny, nz = localDirectionToWorld(source, 4, 0, 0)
			local yx, yy, yz = localDirectionToWorld(source, 0, 4, 0)
			local zx, zy, zz = localDirectionToWorld(source, 0, 0, 4)
			drawDebugLine(x,y,z, 1, 0, 0, x + nx, y + ny, z + nz, 1, 0, 0);
			drawDebugLine(x,y,z, 0, 1, 0, x + yx, y + yy, z + yz, 0, 1, 0);
			drawDebugLine(x,y,z, 0, 0, 1, x + zx, y + zy, z + zz, 0, 0, 1);
		end
	end]]
	if self.isClient then
		if self:getIsActiveForInput() or (self.getIscontrolled ~= nil and self:getIsControlled()) then
			if spec.event_IDs ~= nil and g_dedicatedServerInfo == nil then
				for actionName,eventID in pairs(spec.event_IDs) do
					if actionName == InputAction.VEHICLE_STRAPS_TOGGLE_ATTACH then
						g_inputBinding:setActionEventActive(eventID, anyVehicleInRange)
						g_inputBinding:setActionEventText(eventID, spec.fastened and g_i18n:getText('VEHICLE_STRAPS_DETACH') or g_i18n:getText('VEHICLE_STRAPS_ATTACH'))
					end
				end
			end
			if spec.fastened then
				g_currentMission:addExtraPrintText(g_i18n:getText('VEHICLE_STRAPS_COUNT').." "..spec.vehicleStrapsCount)
				g_currentMission:addExtraPrintText(g_i18n:getText('VEHICLE_STRAPS_MASS').." "..string.format("%.1f",spec.vehicleStrapsMass)..' t')
			else
				g_currentMission:addExtraPrintText(g_i18n:getText('VEHICLE_STRAPS_NO_VEHICLE'))
			end
		end
	end
end
function VehicleStraps:dynamicMountTriggerCallback(superFunc, triggerId, otherActorId, onEnter, onLeave, onStay, otherShapeId)
	local spec = self.spec_vehicleStraps
	local debug = false
	if self.selectionObject.vehicle.isVehicleSaved then
		if onEnter then
			if debug then print('----------------------------------------------------') end
			if debug then print(' enter otherActorId '..otherActorId) end
			local object = g_currentMission:getNodeObject(otherActorId)
			if object == nil then
				if debug then print('enter object nil') end
				object = g_currentMission.nodeToObject[otherActorId]
			end
			if object == self:getRootVehicle() or (self.spec_attachable ~= nil and self.spec_attachable.attacherVehicle == object) then
				object = nil
				if debug then print('enter object nil2') end
			end
			if object ~= nil and object ~= self then
				local rootVehicle
				if otherActorId == object.rootNode then
					rootVehicle = g_currentMission.nodeToObject[object.rootNode]
				end
				if debug then print('enter object.rootNode - '..tostring(object.rootNode)) end
				if rootVehicle ~= nil and spec.vehicles[rootVehicle] == nil then
					spec.vehicles[rootVehicle] = {}
					spec.vehicles[rootVehicle].id = rootVehicle
					spec.vehicles[rootVehicle].fastened = false
					spec.vehicles[rootVehicle].inRange = true
					if debug then print('enter - '..rootVehicle:getFullName()) end
				end
			end
		elseif onLeave then
			if debug then print('----------------------------------------------------') end
			if debug then print(' leave otherActorId '..otherActorId) end
			local object = g_currentMission:getNodeObject(otherActorId)
			if object == nil then
				if debug then print('leave object nil') end
				object = g_currentMission.nodeToObject[otherActorId]
			end
			if object == self:getRootVehicle() or (self.spec_attachable ~= nil and self.spec_attachable.attacherVehicle == object) then
				object = nil
				if debug then print('leave object nil2') end
			end
			if object ~= nil and object ~= self then
				local rootVehicle
				if otherActorId == object.rootNode then
					rootVehicle = g_currentMission.nodeToObject[object.rootNode]
				end
				if rootVehicle ~= nil and spec.vehicles[rootVehicle] ~= nil then
					spec.vehicles[rootVehicle].inRange = false
					if not spec.vehicles[rootVehicle].fastened then
						spec.vehicles[rootVehicle] = nil
					end
					if debug then print('leave - '..rootVehicle:getFullName()) end
				end
			end
		end
	end
	--superFunc(spec, triggerId, otherActorId, onEnter, onLeave, onStay, otherShapeId)
end
function VehicleStraps:fastenVehicles(noEventSend)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	VehicleStrapsFastenVehicleEvent.sendEvent(self, noEventSend)
	
	for _, vehicle in pairs(spec.vehicles) do
		if not vehicle.fastened and vehicle.id ~= self:getRootVehicle() and (self.spec_attachable == nil or (self.spec_attachable ~= nil and self.spec_attachable.attacherVehicle ~= vehicle.id)) then
			local isAttachedImplement = vehicle.id.spec_attachable ~= nil and vehicle.id.spec_attachable.attacherVehicle ~= nil and true or false
			--print('-----------------------------	'..vehicle.id:getFullName()..','..tostring(isAttachedImplement))
			if not isAttachedImplement then
				vehicle.transform = createTransformGroup("transform")
				link(self.rootNode, vehicle.transform)
				local colli = self.rootNode
				local colli2 = vehicle.id.rootNode
				local x,y,z = getWorldTranslation(vehicle.id.rootNode)
				local a,b,c = worldToLocal(self.rootNode, x,y,z)
				setTranslation(vehicle.transform, a, b + 0, c)
				local zX, zY, zZ = localDirectionToWorld(vehicle.id.rootNode, 0, 0, 1)
				local zX, zY, zZ = worldDirectionToLocal(getParent(vehicle.transform), zX, zY, zZ)
				local yX, yY, yZ = localDirectionToWorld(vehicle.id.rootNode, 0, 1, 0)
				local yX, yY, yZ = worldDirectionToLocal(getParent(vehicle.transform), yX, yY, yZ)
				setDirection(vehicle.transform, zX, zY, zZ, yX, yY, yZ)
				local jointTransform = vehicle.transform
				local jointTransform2 = vehicle.id.rootNode
				if self.isServer then
					local constr = JointConstructor:new()                 
					constr:setActors(colli2, colli)
					constr:setJointTransforms(jointTransform2,  jointTransform)
					for i = 1, 3 do
						constr:setTranslationLimit(i-1, true, 0, 0)
						constr:setRotationLimit(i-1, 0, 0)
					end
					vehicle.joint = constr:finalize()
					if vehicle.id.spec_wheels ~= nil and vehicle.id.spec_wheels.wheels ~= nil and vehicle.id.spec_terraTrac == nil then
						for wheelIndex, wheel in pairs(vehicle.id.spec_wheels.wheels) do
							local isCrawler = false
							if vehicle.id.spec_crawlers ~= nil and vehicle.id.spec_crawlers.crawlers ~= nil then
								for _, crawler in pairs(vehicle.id.spec_crawlers.crawlers) do
									if crawler.wheel.node == wheel.node then
										if table.getn(crawler.scrollerNodes) > 0 then
											isCrawler = true
										end
									end
									
								end
							end
							spec.invertedLast = true
							--print('wheel - '..tostring(wheel))
							--print('wheel.xRotOffset - '..tostring(wheel.xRotOffset))
							--print('wheel.hasGroundContact - '..tostring(wheel.hasGroundContact))
							--print('isCrawler - '..tostring(isCrawler))
							if wheel.tireType ~= 44 and not isCrawler and (wheel.xRotOffset ~= nil or wheel.hasTireTracks) and wheel.hasGroundContact then
								self:createWheelChocks(wheelIndex, vehicle.id, spec.invertedLast, false)
								spec.invertedLast = not spec.invertedLast
								self:createWheelChocks(wheelIndex, vehicle.id, spec.invertedLast, false)
							end
						end
					end
				end
				vehicle.fastened = true
			end
		end
	end
	spec.fastened = true
end
function VehicleStraps:unfastenVehicles(noEventSend)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	VehicleStrapsUnfastenVehicleEvent.sendEvent(self, noEventSend)
	
	for _, vehicle in pairs(spec.vehicles) do
		if vehicle.fastened then
			if self.isServer then
				removeJoint(vehicle.joint)
				vehicle.joint = nil
			end
			vehicle.fastened = false
			vehicle.transform = nil
			if not vehicle.inRange then
				spec.vehicles[vehicle.id] = nil
			end
		end
	end
	for _, chock in pairs(spec.wheelChocks) do
		if chock.node ~= nil and entityExists(chock.node) then
			delete(chock.node)
		end
	end
	spec.wheelChocks = {}
	spec.fastened = false
	spec.vehicleStrapsCount = 0
	spec.vehicleStrapsMass = 0
end
function VehicleStraps:createWheelChocks(wheelIndex, vehicle, invertedLast, noEventSend)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	VehicleStrapsCreateChocksEvent.sendEvent(self, wheelIndex, vehicle, invertedLast, noEventSend)
	
	local wheel = vehicle.spec_wheels.wheels[wheelIndex]
	local filename = "$data/shared/assets/wheelChocks/wheelChock01.i3d"
	local i3dNode = g_i3DManager:loadSharedI3DFile(filename, self.baseDirectory, false, false, false)
	if i3dNode ~= 0 then
		local chockNode = getChildAt(i3dNode, 0)
		local posRefNode = I3DUtil.indexToObject(chockNode, getUserAttribute(chockNode, "posRefNode"), self.i3dMappings)
		if posRefNode ~= nil then 
			local chock = {} 
			chock.wheel = wheel 
			chock.node = chockNode 
			chock.scale = {2,1,1}
			setScale(chock.node, unpack(chock.scale))
			chock.isInverted = not invertedLast
			_, chock.height, chock.zOffset = localToLocal(posRefNode, chock.node, 0, 0, 0)
			chock.height = chock.height / chock.scale[2]
			chock.zOffset = chock.zOffset / chock.scale[3]
			chock.offset = {0,0,0}
			setShaderParameter(chockNode, "RDT", 0, 0, 0, 0, false)
			local x, y, z, w = getShaderParameter(chockNode, "RDT")
			self:setWheelChocksPosition(chock, vehicle, false)
			table.insert(spec.wheelChocks, chock)
		end
		delete(i3dNode)
	end
end
function VehicleStraps:setWheelChocksPosition(wheelChock, vehicle)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	setVisibility(wheelChock.node, true)
	local wheel = wheelChock.wheel
	local radiusChockHeightOffset = wheel.radius - wheel.deformation - wheelChock.height
    local angle = math.acos(radiusChockHeightOffset / wheel.radius)
    local zWheelIntersection = wheel.radius * math.sin(angle)
    local zChockOffset = -zWheelIntersection - wheelChock.zOffset
	link(wheel.node, wheelChock.node)
	local yRot
	if vehicle:getFullName() == 'Düvelsdorf Meadow Roller Vario' or vehicle:getFullName() == 'New Holland 3162 Draper 45FT' or vehicle:getFullName() == 'Case IH 3162 TerraFlex Draper 45FT' then
		_, yRot, _ = localRotationToLocal(wheel.repr, wheel.node, getRotation(wheel.repr))
	else
		yRot = 0
	end
    if wheelChock.isInverted then
        yRot = yRot + math.pi
    end
	setRotation(wheelChock.node, 0, yRot, 0)
    local dirX, dirY, dirZ = localDirectionToLocal(wheelChock.node, wheel.node, 0, 0, 1)
    local normX, normY, normZ = localDirectionToLocal(wheelChock.node, wheel.node, 1, 0, 0)
    local posX, posY, posZ = localToLocal(wheel.driveNode, wheel.node, 0, 0, 0)
    posX = posX + normX * wheelChock.offset[1] + dirX * (zChockOffset + wheelChock.offset[3])
    posY = posY + normY * wheelChock.offset[1] + dirY * (zChockOffset + wheelChock.offset[3]) - wheel.radius + wheel.deformation + wheelChock.offset[2]
    posZ = posZ + normZ * wheelChock.offset[1] + dirZ * (zChockOffset + wheelChock.offset[3])
    setTranslation(wheelChock.node, posX, posY, posZ)
end
function VehicleStraps:onUpdateTick(dt)
end
function VehicleStraps:actionCallback(actionName, keyStatus, arg4, arg5, arg6)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	if self:getIsActive() then
		if keyStatus > 0 then
			if actionName == 'VEHICLE_STRAPS_TOGGLE_ATTACH' then
				spec.input_fasten = true
			end
		end
	end
end
function VehicleStraps:onDraw()
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
end
function VehicleStraps:onReadStream(streamId, connection)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	local fastened = streamReadBool(streamId)
	if fastened ~= nil and fastened == true then
		spec.postFasten = true
	end
end
function VehicleStraps:onWriteStream(streamId, connection)
	local spec = self.spec_vehicleStraps
	if not spec.modInitialized or not spec.modAllowed then
		return
	end
	
	streamWriteBool(streamId, spec.fastened)
end

VehicleStrapsFastenVehicleEvent = {}
VehicleStrapsFastenVehicleEvent_mt = Class(VehicleStrapsFastenVehicleEvent, Event)
InitEventClass(VehicleStrapsFastenVehicleEvent, "VehicleStrapsFastenVehicleEvent")
function VehicleStrapsFastenVehicleEvent:emptyNew()
    local self = Event:new(VehicleStrapsFastenVehicleEvent_mt)
    self.className="VehicleStrapsFastenVehicleEvent"
    return self
end
function VehicleStrapsFastenVehicleEvent:new(object)
	local self = VehicleStrapsFastenVehicleEvent:emptyNew()
	self.object = object
	return self
end
function VehicleStrapsFastenVehicleEvent:readStream(streamId, connection)
	self.object = NetworkUtil.readNodeObject(streamId)
    self:run(connection)
end
function VehicleStrapsFastenVehicleEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.object)
end
function VehicleStrapsFastenVehicleEvent:run(connection)
	if self.object ~= nil then
		self.object:fastenVehicles(true)
	end
	if not connection:getIsServer() then
		g_server:broadcastEvent(VehicleStrapsFastenVehicleEvent:new(self.object), nil, connection, self.object)
	end
end
function VehicleStrapsFastenVehicleEvent.sendEvent(vehicle, noEventSend)
	if noEventSend == nil or noEventSend == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VehicleStrapsFastenVehicleEvent:new(vehicle), nil, nil, vehicle)
		else
			g_client:getServerConnection():sendEvent(VehicleStrapsFastenVehicleEvent:new(vehicle))
		end
	end
end

VehicleStrapsUnfastenVehicleEvent = {}
VehicleStrapsUnfastenVehicleEvent_mt = Class(VehicleStrapsUnfastenVehicleEvent, Event)
InitEventClass(VehicleStrapsUnfastenVehicleEvent, "VehicleStrapsUnfastenVehicleEvent")
function VehicleStrapsUnfastenVehicleEvent:emptyNew()
    local self = Event:new(VehicleStrapsUnfastenVehicleEvent_mt)
    self.className="VehicleStrapsUnfastenVehicleEvent"
    return self
end
function VehicleStrapsUnfastenVehicleEvent:new(object)
	local self = VehicleStrapsUnfastenVehicleEvent:emptyNew()
	self.object = object
	return self
end
function VehicleStrapsUnfastenVehicleEvent:readStream(streamId, connection)
	self.object = NetworkUtil.readNodeObject(streamId)
    self:run(connection)
end
function VehicleStrapsUnfastenVehicleEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.object)
end
function VehicleStrapsUnfastenVehicleEvent:run(connection)
	if self.object ~= nil then
		self.object:unfastenVehicles(true)
	end
	if not connection:getIsServer() then
		g_server:broadcastEvent(VehicleStrapsUnfastenVehicleEvent:new(self.object), nil, connection, self.object)
	end
end
function VehicleStrapsUnfastenVehicleEvent.sendEvent(vehicle, noEventSend)
	if noEventSend == nil or noEventSend == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VehicleStrapsUnfastenVehicleEvent:new(vehicle), nil, nil, vehicle)
		else
			g_client:getServerConnection():sendEvent(VehicleStrapsUnfastenVehicleEvent:new(vehicle))
		end
	end
end

VehicleStrapsCreateChocksEvent = {}
VehicleStrapsCreateChocksEvent_mt = Class(VehicleStrapsCreateChocksEvent, Event)

InitEventClass(VehicleStrapsCreateChocksEvent, "VehicleStrapsCreateChocksEvent")

function VehicleStrapsCreateChocksEvent:emptyNew()
    local self = Event:new(VehicleStrapsCreateChocksEvent_mt)
    self.className="VehicleStrapsCreateChocksEvent"
    return self
end
function VehicleStrapsCreateChocksEvent:new(object, wheelIndex, vehicle, invertedLast)
	local self = VehicleStrapsCreateChocksEvent:emptyNew()
	self.object = object
	self.wheelIndex = wheelIndex
	self.vehicle = vehicle
	self.invertedLast = invertedLast
	return self
end
function VehicleStrapsCreateChocksEvent:readStream(streamId, connection)
	self.object = NetworkUtil.readNodeObject(streamId)
	self.wheelIndex = streamReadInt16(streamId)
	self.vehicle = NetworkUtil.readNodeObject(streamId)
    self.invertedLast = streamReadBool(streamId)
    self:run(connection)
end
function VehicleStrapsCreateChocksEvent:writeStream(streamId, connection)
	NetworkUtil.writeNodeObject(streamId, self.object)
	streamWriteInt16(streamId, self.wheelIndex)
	NetworkUtil.writeNodeObject(streamId, self.vehicle)
	streamWriteBool(streamId, self.invertedLast)
end
function VehicleStrapsCreateChocksEvent:run(connection)
	if self.object ~= nil then
		self.object:createWheelChocks(self.wheelIndex, self.vehicle, self.invertedLast, true)
	end
	if not connection:getIsServer() then
		g_server:broadcastEvent(VehicleStrapsCreateChocksEvent:new(self.object, self.wheelIndex, self.vehicle, self.invertedLast), nil, connection, self.object)
	end
end
function VehicleStrapsCreateChocksEvent.sendEvent(object, wheelIndex, vehicle, invertedLast, noEventSend)
	if noEventSend == nil or noEventSend == false then
		if g_server ~= nil then
			g_server:broadcastEvent(VehicleStrapsCreateChocksEvent:new(object, wheelIndex, vehicle, invertedLast), nil, nil, object)
		else
			g_client:getServerConnection():sendEvent(VehicleStrapsCreateChocksEvent:new(object, wheelIndex, vehicle, invertedLast))
		end
	end
end