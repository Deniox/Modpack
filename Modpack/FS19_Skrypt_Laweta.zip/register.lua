--
-- FS19 - Vehicle Straps
-- @author:    	kenny456 (kenny456@seznam.cz)
-- @history:	v1.0.0.0 - 2020-11-25 - first release
--
source(Utils.getFilename("vehicleStraps.lua", g_currentModDirectory))

VehicleStraps_register = {}

function VehicleStraps_register:loadMap()
end
function VehicleStraps_register:register(name)
	if g_specializationManager:getSpecializationByName("VehicleStraps") == nil then
		if VehicleStraps == nil then 
			print("ERROR: unable to add specialization 'VehicleStraps'")
		else 
			for i, typeDef in pairs(g_vehicleTypeManager.vehicleTypes) do
				if typeDef ~= nil and i ~= "locomotive" then 
					local isDynamicMountAttacher  = false
					local isTrailer  = false
					local isTransportTrailer  = false
					for name, spec in pairs(typeDef.specializationsByName) do
						if name == "dynamicMountAttacher"  then 
							isDynamicMountAttacher = true 
						elseif name == "trailer"  then 
							isTrailer = true 
						end 
					end
					if i == "transportTrailer" then
						isTransportTrailer = true
					end
					if isDynamicMountAttacher or isTrailer or isTransportTrailer then
					  typeDef.specializationsByName["VehicleStraps"] = VehicleStraps
					  table.insert(typeDef.specializationNames, "VehicleStraps")
					  table.insert(typeDef.specializations, VehicleStraps)  
					end 
				end 
			end   
		end 
	end
end
VehicleTypeManager.finalizeVehicleTypes = Utils.prependedFunction(VehicleTypeManager.finalizeVehicleTypes, VehicleStraps_register.register)
print("----VehicleStraps registered.")

addModEventListener(VehicleStraps_register);