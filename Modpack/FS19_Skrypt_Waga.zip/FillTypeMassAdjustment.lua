-- by modelleicher
-- www.ls-modcompany.com
-- Version 5 (FS19 conversion)
-- now FS19 ready! :) 20.11.2018

FillTypeMassAdjustment = {};

function FillTypeMassAdjustment:loadMap(name)
	print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ")
	print("FillType Mass Adjustment FS19 by modelleicher loaded.");
	print("............................................................................................................")
	-- all new mass values according to real values:
	local realMass = {};
	
	 realMass.UNKNOWN = 0
	 realMass.WHEAT = 0.790 -- 710kg to 820kg says google
	 realMass.BARLEY = 0.630 -- 580kg to 780kg says google
	 realMass.OAT = 0.49 -- 450kg to 500kg says google
	 realMass.COTTON = 0.21 -- no idea here.. Since its baled up stuff.. open for suggestions
	 realMass.CANOLA = 0.720 -- 700kg to 750kg says google
	 realMass.SUNFLOWER = 0.350; -- according to google
	 realMass.SOYBEAN = 0.700 -- according to google
	 realMass.MAIZE = 0.800 -- 800kg per m³ of corn
	 realMass.POTATO = 0.730 -- potatos around 720kg to 740kg per m³
	 realMass.SUGARBEET = 0.740 -- sugar beet around 740kg per m³
	 realMass.OILSEEDRADISH = 0.75; -- according to google, giants default was 0.000205
	 realMass.POPLAR = 0.45; -- not sure about this one
	 realMass.GRASS = 0.350 -- 350kg per 1m³ of fresh cut grass
	 realMass.GRASS_WINDROW = 0.350 -- 350kg same as grass, its still the same stuff lol
	 realMass.DRYGRASS = 0.070 -- between 70kg and 170kg (baled)
	 realMass.DRYGRASS_WINDROW = 0.070 -- still the same as dryGrass I guess
	 realMass.SUGARCANE = 0.19 -- not sure.. 
	 realMass.MILK = 1.02 -- between 1020 and 1030kg per m³
	 realMass.FUEL = 0.800 -- what is fuel.. Gasoline is 750kg and diesel is 850.. so maybe in the middle?
	 realMass.WATER = 1 -- no brainer
	 realMass.SEEDS = 0.350 -- depends on the fruit lol.. but I think thats a good middle ground
	 realMass.WOOL = 0.200 -- 200kg per m3 of wool.. a bit much I think but tightly packed maybe?
	 realMass.FORAGE = 0.320 -- not sure about this one
	 realMass.FORAGE_MIXING = 0.285 -- not sure about this one either
	 realMass.CHAFF = 0.460  -- chaff between 350kg and 700kg per m³ depending on how dry, so we use a value in between
	 realMass.TREESAPLINGS = 0.2 -- no idea..
	 realMass.WOODCHIPS = 0.360 -- about 360kg per m³
	 realMass.EGG = 0.01 -- one egg? lol
	 realMass.SILAGE = 0.700 -- 700kg per m³ of maize silage, grass a bit ligher.. Not sure on this value.
	 realMass.STRAW = 0.04; -- 40kg per m³ i think is about right.. default was 30kg
	 realMass.DIESEL = 0.840 -- 840 to 850 depending on biodiesel content
	 realMass.DEF = 1 -- I guess? :D 
	 realMass.AIR = 0 -- I guess We can ignore that..
	 -- the difficult ones
	 -- TO DO
	 realMass.ROUNDBALE = 150
	 realMass.ROUNDBALE_GRASS = 150
	 realMass.ROUNDBALE_DRYGRASS = 150
	 realMass.ROUNDBALE_WHEAT = 150
	 realMass.ROUNDBALE_BARLEY = 150
	 realMass.SQUAREBALE = 150
	 realMass.SQUAREBALE_WHEAT = 150
	 realMass.SQUAREBALE_BARLEY = 150
	 -- 
	 realMass.FERTILIZER = 1.1 -- that stuff is heavy
	 realMass.LIQUIDFERTILIZER = 1 -- mostly water
	 realMass.MANURE = 0.790 -- between 600kg and even 850kg in extreme situations for 1m³ of manure
	 realMass.LIQUIDMANURE = 0.980 -- between 950m³ and over 1000kg per m³
	 realMass.DIGESTATE = 0.500 -- lighter than liquid manure
	 realMass.PIGFOOD = 0.610 -- maybe
	 realMass.TARP = 0
	 realMass.LIME = 1.1 -- between 800kg and 1300kg per m³ says google
	 realMass.HERBICIDE = 1 -- basically water
	 realMass.WEED = 1.5 -- what and why :D 
	 -- I think 650kg is a nice weight for a big horse :D 
	 realMass.HORSE_TYPE_BEIGE = 0.650
	 realMass.HORSE_TYPE_BLACK = 0.650
	 realMass.HORSE_TYPE_BROWN = 0.650
	 realMass.HORSE_TYPE_BROWN_WHITE = 0.650
	 realMass.HORSE_TYPE_DARK_BROWN = 0.650
	 realMass.HORSE_TYPE_GREY = 0.650
	 realMass.HORSE_TYPE_LIGHT_BROWN = 0.650
	 realMass.HORSE_TYPE_RED_BROWN = 0.650
	 -- cows.. 680kg is a good cow I'd say
	 realMass.COW_TYPE_BROWN = 0.680
	 realMass.COW_TYPE_BROWN_WHITE = 0.680
	 realMass.COW_TYPE_BLACK = 0.680
	 realMass.COW_TYPE_BLACK_WHITE = 0.680
	 -- brahmans might be a bit heavier maybe so 700kg
	 realMass.COW_TYPE_BRAHMAN_BROWN = 0.700
	 realMass.COW_TYPE_BRAHMAN_WHITE = 0.700
	 realMass.COW_TYPE_BRAHMAN_LIGHT_BROWN = 0.700
	 realMass.COW_TYPE_BRAHMAN_GREY = 0.700
	 -- sheeps, google says 45kg to 160kg.. lets make that 100kg
	 realMass.SHEEP_TYPE_WHITE = 0.100
	 realMass.SHEEP_TYPE_BROWN = 0.100
	 realMass.SHEEP_TYPE_BLACK_WHITE = 0.100
	 realMass.SHEEP_TYPE_BLACK = 0.100
	 -- pigs, google says 250 to 360 for the most common breeds
	 realMass.PIG_TYPE_RED = 0.300
	 realMass.PIG_TYPE_WHITE = 0.300
	 realMass.PIG_TYPE_BLACK_WHITE = 0.300
	 realMass.PIG_TYPE_BLACK = 0.300
	 -- chickens google says 1-3kg roughly 
	 realMass.CHICKEN_TYPE_BLACK = 0.002
	 realMass.CHICKEN_TYPE_WHITE = 0.002
	 realMass.CHICKEN_TYPE_BROWN = 0.002
	 realMass.CHICKEN_TYPE_ROOSTER = 0.002

	
	-----
	-- if you want to add a custom fruitType with a custom mass you can just add it to the realMass Table
	-- realMass.NAME_OF_CUSTOM_FRUITTYPE = VALUE_IN_TONS_PER_M3
	-----
	

	
	
	for k, v in pairs(g_currentMission.fillTypeManager.fillTypes) do
		if realMass[v.name] ~= nil then
			v.massPerLiter = realMass[v.name] * 0.001;
			print("Fillable mass of Filltype "..tostring(v.name).." changed to "..tostring(v.massPerLiter*1000).." tons per m³ (or Piece) (according to real mass table)");
		end;
	end;
	
	
	print("FillTypeMassAdjustment all fillType mass values have been updated. Note: This Log entry should only exist once, if you have several of these please check to make sure you don't have several FillTypeMassAdjustment Versions in your Modfolder.")
	print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ")
end;
function FillTypeMassAdjustment:keyEvent(unicode, sym, modifier, isDown)
end;
function FillTypeMassAdjustment:update(dt)
end;
function FillTypeMassAdjustment:draw()
end;
function FillTypeMassAdjustment:deleteMap()
end;
function FillTypeMassAdjustment:mouseEvent(posX, posY, isDown, isUp, button)
end;

addModEventListener(FillTypeMassAdjustment);







