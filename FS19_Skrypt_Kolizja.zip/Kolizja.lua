Kolizja = {}; 

function Kolizja:loadMap(name)
	PlacementScreenController.DISPLACEMENT_COST_PER_M3 = 1;
	PlacementUtil.hasObjectOverlap = Utils.overwrittenFunction(PlacementUtil.hasObjectOverlap, Kolizja.hasObjectOverlap);
	PlacementUtil.isInsidePlacementPlaces = Utils.overwrittenFunction(PlacementUtil.isInsidePlacementPlaces, Kolizja.isInsidePlacementPlaces);
	PlacementUtil.isInsideRestrictedZone = Utils.overwrittenFunction(PlacementUtil.isInsideRestrictedZone, Kolizja.isInsideRestrictedZone);
	PlacementUtil.hasOverlapWithPoint = Utils.overwrittenFunction(PlacementUtil.hasOverlapWithPoint, Kolizja.hasOverlapWithPoint);
	TerrainDeformation.setDynamicObjectCollisionMask = Utils.overwrittenFunction(TerrainDeformation.setDynamicObjectCollisionMask, Kolizja.setDynamicObjectCollisionMask);
	PlacementScreenController.onTerrainValidationFinished = Utils.overwrittenFunction(PlacementScreenController.onTerrainValidationFinished, Kolizja.onTerrainValidationFinished);
	TerrainDeformation.setBlockedAreaMap = Utils.overwrittenFunction(TerrainDeformation.setBlockedAreaMap, Kolizja.setBlockedAreaMap);
end; 

function Kolizja:deleteMap()
end;

function Kolizja:mouseEvent(posX, posY, isDown, isUp, button) 
end;

function Kolizja:keyEvent(unicode, sym, modifier, isDown) 
end;

function Kolizja:update(dt) 
end;

function Kolizja:draw(Kolizja)
end;

function Kolizja:setBlockedAreaMap(superFunc, ...)
	return true;
end

function Kolizja:hasObjectOverlap(superFunc, ...)   
	return false;
end

function Kolizja:isInsidePlacementPlaces(superFunc, ...)   
	return false;
end

function Kolizja:isInsideRestrictedZone(superFunc, ...)   
	return false;
end

function Kolizja:hasOverlapWithPoint(superFunc, ...)   
	return false;
end

function Kolizja:setOutsideAreaConstraints(superFunc, ...)   
	return superFunc(self, 0, 0, 0);
end

function Kolizja:setDynamicObjectCollisionMask(superFunc, ...)   
	return superFunc(self, 0);
end

function Kolizja:onTerrainValidationFinished(superFunc, p1, p2, p3)      
    return superFunc(self, 0, p2, p3);
end

addModEventListener(Kolizja);