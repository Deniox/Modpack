Paliwo = {}

function Paliwo:startLoadingModifier(fillType, fillableObject, fillUnitIndex)
	local fillTypeName = g_fillTypeManager.indexToName[fillType]
	if fillTypeName == "DIESEL" then
		self.fillLitersPerMS = 1/3000; -- 1.5 L na sekunde
	end;
end;

LoadTrigger.startLoading = Utils.prependedFunction(LoadTrigger.startLoading, Paliwo.startLoadingModifier)