setAttachEvent = {};
setAttachEvent_mt = Class(setAttachEvent, Event);

InitEventClass(setAttachEvent, "setAttachEvent");

function setAttachEvent:emptyNew()
    local self = Event:new(setAttachEvent_mt);
	self.className="setAttachEvent";
    return self;
end

function setAttachEvent:new(vehicle, vehicleId, jointId)
    local self = setAttachEvent:emptyNew()
    self.vehicle = vehicle;
    self.vehicleId = vehicleId;
    self.jointId = jointId;
    return self;
end

function setAttachEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId);
    self.vehicleId = NetworkUtil.readNodeObject(streamId);
    self.jointId = streamReadInt32(streamId);
    self:run(connection);
end

function setAttachEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle);
    NetworkUtil.writeNodeObject(streamId, self.vehicleId);
    streamWriteInt32(streamId, self.jointId);
end

function setAttachEvent:run(connection)
    TowingChain.attachObject(self.vehicle, self.vehicleId, self.jointId, true);
    if not connection:getIsServer() then
        g_server:broadcastEvent(setAttachEvent:new(self.vehicle, self.vehicleId, self.jointId), nil, connection, self.vehicle);
    end
end

function setAttachEvent.sendEvent(vehicle, vehicleId, jointId, noEventSend)
    if noEventSend == nil or noEventSend == false then
        if g_server ~= nil then
            g_server:broadcastEvent(setAttachEvent:new(vehicle, vehicleId, jointId), nil, nil, vehicle);
        else
            g_client:getServerConnection():sendEvent(setAttachEvent:new(vehicle, vehicleId, jointId));
        end
    end

end

setDetachEvent = {};
setDetachEvent_mt = Class(setDetachEvent, Event);

InitEventClass(setDetachEvent, "setDetachEvent");

function setDetachEvent:emptyNew()
    local self = Event:new(setDetachEvent_mt);
	self.className="setDetachEvent";
    return self;
end

function setDetachEvent:new(vehicle)
    local self = setDetachEvent:emptyNew()
    self.vehicle = vehicle;
    return self;
end

function setDetachEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId);
    self:run(connection);
end

function setDetachEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle);
end

function setDetachEvent:run(connection)
    TowingChain.detachObject(self.vehicle, true);
    if not connection:getIsServer() then
        g_server:broadcastEvent(setDetachEvent:new(self.vehicle), nil, connection, self.vehicle);
    end
end

function setDetachEvent.sendEvent(vehicle, noEventSend)
    if noEventSend == nil or noEventSend == false then
        if g_server ~= nil then
            g_server:broadcastEvent(setDetachEvent:new(vehicle), nil, nil, vehicle);
        else
            g_client:getServerConnection():sendEvent(setDetachEvent:new(vehicle));
        end
    end

end
