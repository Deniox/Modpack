TowingChain_register = {}

function TowingChain_register:loadMap()
	for _,n in pairs( { "TOWINGCHAIN_VEHICLE_ATTACH", "TOWINGCHAIN_VEHICLE_DETACH", "TOWINGCHAIN_MANUAL_ATTACH_ON", "TOWINGCHAIN_MANUAL_ATTACH_OFF", "TOWINGCHAIN_VEHICLE_THROTTLE_ON", "TOWINGCHAIN_VEHICLE_THROTTLE_OFF", "TOWINGCHAIN_SELF_ATTACH", "TOWINGCHAIN_SELF_DETACH" } ) do
		TowingChain:getTexts(n, g_i18n:getText(n))
	end
end

function TowingChain_register.registerSpecializationVehicle(vehicleType, specialization, specName)
    --print("-----register specialization to vehicleType : ".. vehicleType.name)
    table.insert(vehicleType.specializationNames, specName)
    vehicleType.specializationsByName[specName] = specialization
    table.insert(vehicleType.specializations, specialization)
end

g_specializationManager.addSpecialization('towingChain', 'towingChain', 'TowingChain',  Utils.getFilename("Script/towingChain.lua", g_currentModDirectory))
    
if  g_vehicleTypeManager.vehicleTypes.towingChain ~= nil then
    TowingChain_register.registerSpecializationVehicle(g_vehicleTypeManager.vehicleTypes.towingChain, TowingChain, 'towingChain')
end
print("----TowingChain registered.")

addModEventListener(TowingChain_register);