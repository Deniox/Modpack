--
-- FS19 - Towing Chain v1.1
-- @author:    	Stefan Geiger, kenny456 - FS19 conversion (kenny456@seznam.cz)
-- @history:	v1.1 - 2019-01-11 - converted to FS19
--								  - added manual attaching function
--								  - added function to turn on / off pulled vehicle's throttle
--
TowingChain = {};

source(g_currentModDirectory .. "Script/SetAttachEvent.lua");
function TowingChain:getTexts(i,text)
	if g_currentMission.TowingChain == nil then
		g_currentMission.TowingChain = {}
		g_currentMission.TowingChain.texts = {}
	end
	g_currentMission.TowingChain.texts[i] = text
end

function TowingChain.prerequisitesPresent(specializations)
	return true
end

function TowingChain.initSpecialization()
end

function TowingChain.registerOverwrittenFunctions(vehicleType)
	Player.registerActionEvents = Utils.appendedFunction(Player.registerActionEvents, TowingChain.registerActionEventsPlayer);
end

function TowingChain.registerFunctions(vehicleType)
end

function TowingChain.registerEvents(vehicleType)
end

function TowingChain:registerActionEventsPlayer()
end

function TowingChain:registerActionEventsMenu()
end

function TowingChain:onRegisterActionEvents(isSelected, isOnActiveVehicle)
	if isSelected then
		if self.TowingChain == nil then 
			self.TowingChain = {}
		else	
			self:clearActionEventsTable( self.TowingChain )
		end 
		for _,actionName in pairs({ "TOWINGCHAIN_ATTACH_VEHICLE",
								"TOWINGCHAIN_MANUAL_ATTACH",
								"TOWINGCHAIN_VEHICLE_THROTTLE"} ) do
			local _, eventName = self:addActionEvent(self.TowingChain, InputAction[actionName], self, TowingChain.actionCallback, true, true, false, true, nil);
			if g_inputBinding ~= nil and g_inputBinding.events ~= nil and g_inputBinding.events[eventName] ~= nil then
				if isSelected then
					if actionName ~= 'TOWINGCHAIN_VEHICLE_THROTTLE' then
						g_inputBinding.events[eventName].displayPriority = 1
					else
						g_inputBinding.events[eventName].displayPriority = 2
					end
				elseif  isOnActiveVehicle then
					g_inputBinding.events[eventName].displayPriority = 3
				end
			end
		end
	end
end

function TowingChain.registerEventListeners(vehicleType)
	for _,n in pairs( { "onLoad", "onUpdate", "onUpdateTick", "onDraw", "onReadStream", "onWriteStream", "onRegisterActionEvents" } ) do
		SpecializationUtil.registerEventListener(vehicleType, n, TowingChain)
	end
end

function TowingChain:onLoad(vehicle)
	self.detachObject = TowingChain.detachObject;
    self.attachObject = TowingChain.attachObject;
    self.playerInRange = TowingChain.playerInRange;
    self.attachPoint = I3DUtil.indexToObject(self.components, getXMLString(self.xmlFile,"vehicle.towingChain#index"));
    self.attachPointColli = I3DUtil.indexToObject(self.components, getXMLString(self.xmlFile,"vehicle.towingChain#rootNode"));
    self.isUsed = false
	self.isUsedSelf = false
    self.joint = {};
    self.lastVehicle = nil;
	local baseName = "vehicle"
	self.sampleAttach = g_soundManager:loadSampleFromXML(self.xmlFile, baseName, "attachSound", self.baseDirectory, self.components, 1, AudioGroup.VEHICLE, self.i3dMappings, self)
	self.inputChainAttachVehicle = false
	self.inputChainManualAttach = false
	self.inputChainVehicleThrottle = false
	self.attachedVehicleThrottle = false
	self.isDetachAllowed = Utils.overwrittenFunction(self.isDetachAllowed, TowingChain.isDetachAllowed)
	self.getIsTurnedOn = TowingChain.getIsTurnedOn
end


function TowingChain:onUpdate(dt)
	if not self:getIsActiveForInput() then
		if self.lastVehicle ~= nil then 
            if not self.isUsed then
                if self.inputChainManualAttach and TowingChain.playerInRange(self) then                    
                    self:attachObject(self.lastVehicle[1],self.lastVehicle[2],nil);
					g_soundManager:playSample(self.sampleAttach);
					self.inputChainManualAttach = false
                end;
            end;
        end
	elseif self:getIsActiveForInput() then
        if self.lastVehicle ~= nil then 
            if not self.isUsed then
                if self.inputChainAttachVehicle then           
                    self:attachObject(self.lastVehicle[1],self.lastVehicle[2],nil);
					g_soundManager:playSample(self.sampleAttach);
					self.inputChainAttachVehicle = false
					self.inputChainManualAttach = false
                end;
            end;
        else
            if self.isUsed then
                if self.inputChainAttachVehicle then
					if not self.attachedVehicleThrottle then
						self:detachObject();
						g_soundManager:playSample(self.sampleAttach);
						self.inputChainAttachVehicle = false
					else
						g_currentMission:showBlinkingWarning('First turn off attached vehicle throttle to detach Tow chain!', 2000);
					end
                end;
            else
				if self.inputChainAttachVehicle then
					if self.spec_attachable ~= nil then
						if self.spec_attachable.attacherVehicle ~= nil then
							local jointDesc = self.spec_attachable.attacherVehicle:getAttacherJointIndexFromObject(self)
							if jointDesc ~= nil then
								self.isUsedSelf = true
								self:attachObject(self.spec_attachable.attacherVehicle,jointDesc,nil);
								g_soundManager:playSample(self.sampleAttach);
								self.inputChainAttachVehicle = false
							end
						end
					end
				end
			end;
        end;
		if self.isUsed then
		if not self.isUsedSelf then
            if self.attachedVehicleThrottle then
                if self.inputChainVehicleThrottle then
                    self.attachedVehicleThrottle = false
					self.inputChainVehicleThrottle = false
                    if self.joint.vehicleId.spec_drivable ~= nil then
						if self.joint.vehicleId.spec_drivable.reverserDirection ~= nil then
							TowingChain.leaveVehicle(self.joint.vehicleId, self.joint.vehicleId.leaveVehicle)
						end
                    elseif self.joint.vehicleId.spec_attachable ~= nil then
						if self.joint.vehicleId.spec_attachable.attacherVehicle ~= nil then
							if self.joint.vehicleId.spec_attachable.attacherVehicle.spec_drivable ~= nil then
								if self.joint.vehicleId.spec_attachable.attacherVehicle.spec_drivable.reverserDirection ~= nil then
									TowingChain.leaveVehicle(self.joint.vehicleId.spec_attachable.attacherVehicle, self.joint.vehicleId.spec_attachable.attacherVehicle.leaveVehicle)
								end
							end
						end
                    end
                end
            else
                if self.inputChainVehicleThrottle then
                    self.attachedVehicleThrottle = true
					self.inputChainVehicleThrottle = false
                end
            end
        end
        end
		if self.attachedVehicleThrottle then
			local attVehicle
			local tempVehicle
			if self.spec_attachable.attacherVehicle ~= nil then
				tempVehicle = self.spec_attachable.attacherVehicle
			end
			while true do
				if tempVehicle.spec_drivable ~= nil then
					attVehicle = tempVehicle
					break
				else
					if tempVehicle.spec_attachable ~= nil then
						if tempVehicle.spec_attachable.attacherVehicle ~= nil then
							tempVehicle = tempVehicle.spec_attachable.attacherVehicle
						else
							attVehicle = nil
							break
						end
					else
						attVehicle = nil
						break
					end
				end
			end
			if attVehicle ~= nil then
				if self.joint.vehicleId.spec_drivable ~= nil then
					if self.joint.vehicleId.spec_drivable.reverserDirection ~= nil then
						Drivable.updateVehiclePhysics(self.joint.vehicleId, attVehicle.spec_drivable.axisForward, attVehicle.spec_drivable.axisSide, attVehicle.spec_drivable.doHandbrake, dt)
					end
				elseif self.joint.vehicleId.spec_attachable ~= nil then
					if self.joint.vehicleId.spec_attachable.attacherVehicle ~= nil then
						if self.joint.vehicleId.spec_attachable.attacherVehicle.spec_drivable ~= nil then
							if self.joint.vehicleId.spec_attachable.attacherVehicle.spec_drivable.reverserDirection ~= nil then
								Drivable.updateVehiclePhysics(self.joint.vehicleId.spec_attachable.attacherVehicle, attVehicle.spec_drivable.axisForward, attVehicle.spec_drivable.axisSide, attVehicle.spec_drivable.doHandbrake, dt)
							end
						end
					end
				end
			end
		end
	end
	if self:getIsActiveForInput() then
		if self.TowingChain ~= nil then
			if self.lastVehicle ~= nil then
				g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, true)
				g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_MANUAL_ATTACH.actionEventId, true)
				g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, false)
				g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_VEHICLE_ATTACH'])
			elseif self.lastVehicle == nil then
				if self.isUsed then
					g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, true)
					g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_MANUAL_ATTACH.actionEventId, false)
					if self.isUsedSelf then
						g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, false)
						g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_SELF_DETACH'])
					else
						g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_VEHICLE_DETACH'])
						g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, true)
					end
					
					if self.attachedVehicleThrottle then
						g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_VEHICLE_THROTTLE_OFF'])
					else
						g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_VEHICLE_THROTTLE_ON'])
					end
				elseif not self.isUsed then
					g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, true)
					g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_MANUAL_ATTACH.actionEventId, true)
					g_inputBinding:setActionEventTextVisibility(self.TowingChain.TOWINGCHAIN_VEHICLE_THROTTLE.actionEventId, false)
					g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_ATTACH_VEHICLE.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_SELF_ATTACH'])
				end
			end
			if not self.isUsed then
				if self.inputChainManualAttach == true then
					g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_MANUAL_ATTACH.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_MANUAL_ATTACH_OFF'])
				else
					g_inputBinding:setActionEventText(self.TowingChain.TOWINGCHAIN_MANUAL_ATTACH.actionEventId, g_currentMission.TowingChain.texts['TOWINGCHAIN_MANUAL_ATTACH_ON'])
				end
			end
		end
	end
end
function TowingChain:onUpdateTick(dt)
	if (self:getIsActiveForInput() or self.inputChainManualAttach == true) and not self.isUsed then
		self.lastVehicle = nil;
		local x,y,z = getWorldTranslation(self.attachPoint);
		for k,v in pairs(g_currentMission.vehicles) do
			if v ~= self.spec_attachable.attacherVehicle then
				local vx, vy, vz = getWorldTranslation(v.rootNode);
				if MathUtil.vector3Length(x - vx, y - vy, z - vz) <= 50 then
					if v.spec_attacherJoints ~= nil then
						for index,joint in pairs(v.spec_attacherJoints.attacherJoints) do
							if joint.jointType == AttacherJoints.JOINTTYPE_TRAILER or joint.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW then
								local x1,y1,z1 = getWorldTranslation(joint.jointTransform);
								local distance = MathUtil.vector3Length(x-x1,y-y1,z-z1);
								if distance <= 1.5 then                        
									self.lastVehicle = {};
									self.lastVehicle[1] = v;
									self.lastVehicle[2] = index;
									break;
								end;
							end;
						end;
						if v.spec_attacherJoints.attacherJoint ~= nil and self.lastVehicle == nil then
							if v.attacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILER or v.attacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW then
								local x1,y1,z1 = getWorldTranslation(v.spec_attacherJoints.attacherJoint.node);
								local distance = MathUtil.vector3Length(x-x1,y-y1,z-z1);
								if distance <= 1 then                        
									self.lastVehicle = {};
									self.lastVehicle[1] = v;
									self.lastVehicle[2] = 0;
									break;
								end;
							end;
						end;
					end;
				end;
			end;
		end;
    end;
end
function TowingChain:attachObject(vehicleId,jointId,noEventSend,vehicle)
    setAttachEvent.sendEvent(self,vehicleId,jointId,noEventSend);
    local joint = self.joint;
    joint.vehicle = vehicleId;
    local jointFA = nil;
    if jointId == 0 then
        jointFA = vehicleId.spec_attacherJoints.attacherJoint;
    else
        jointFA = vehicleId.spec_attacherJoints.attacherJoints[jointId];
    end;
    
    if vehicleId.isBroken == true then
        vehicleId.isBroken = false;
    end;
    if self.isServer then
		if vehicleId == self.spec_attachable.attacherVehicle then
			self.isUsedSelf = true
		end
        local colli = jointFA.rootNode; 
        local colli2 = self.attachPointColli;
        local jointTransform = Utils.getNoNil(jointFA.jointTransform, jointFA.node);
        local jointTransform2 = self.attachPoint;
    
        local constr = JointConstructor:new();                    
        constr:setActors(colli2, colli);
        constr:setJointTransforms(jointTransform2,  jointTransform);
        for i=1, 3 do
            constr:setTranslationLimit(i-1, true, 0, 0);
            --constr:setRotationLimit(i-1,0,0);
        end;
        self.joint.index = constr:finalize();
		if self.isUsedSelf == false then
			if vehicleId.spec_drivable ~= nil then
				if vehicleId.spec_drivable.reverserDirection ~= nil then
					TowingChain.leaveVehicle(vehicleId, vehicleId.leaveVehicle)
				end
			elseif vehicleId.spec_attachable ~= nil then
				if vehicleId.spec_attachable.attacherVehicle ~= nil then
					if vehicleId.spec_attachable.attacherVehicle.spec_drivable ~= nil then
						if vehicleId.spec_attachable.attacherVehicle.spec_drivable.reverserDirection ~= nil then
							TowingChain.leaveVehicle(vehicleId.spec_attachable.attacherVehicle, vehicleId.spec_attachable.attacherVehicle.leaveVehicle)
						end
					end
				end
			end
		end
		self.joint.attacherJointId = jointId
		if self.isUsedSelf == false then
			if vehicleId.leaveVehicle ~= nil then
				vehicleId.backupLeaveVehicle = vehicleId.leaveVehicle
				vehicleId.leaveVehicle = Utils.overwrittenFunction(vehicleId.leaveVehicle, TowingChain.leaveVehicle)
			elseif vehicleId.spec_attachable ~= nil then
				if vehicleId.spec_attachable.attacherVehicle ~= nil then
					if vehicleId.spec_attachable.attacherVehicle.leaveVehicle ~= nil then
						vehicleId.spec_attachable.attacherVehicle.backupLeaveVehicle = vehicleId.spec_attachable.attacherVehicle.leaveVehicle
						vehicleId.spec_attachable.attacherVehicle.leaveVehicle = Utils.overwrittenFunction(vehicleId.spec_attachable.attacherVehicle.leaveVehicle, TowingChain.leaveVehicle)
					end
				end
			end
		end
    end;
    vehicleId.forceIsActive = true;
	self.joint.vehicleId = vehicleId
    self.isUsed = true;
    self.lastVehicle = nil;
end;
function TowingChain:detachObject(noEventSend)
    setDetachEvent.sendEvent(self,noEventSend);
    if self.isServer then
		if self.isUsedSelf == false then
			if self.joint.vehicleId.leaveVehicle ~= nil and self.joint.vehicleId.backupLeaveVehicle ~= nil then
				self.joint.vehicleId.leaveVehicle = self.joint.vehicleId.backupLeaveVehicle
				self.joint.vehicleId.backupLeaveVehicle = nil
			elseif self.joint.vehicleId.spec_attachable ~= nil then
				if self.joint.vehicleId.spec_attachable.attacherVehicle ~= nil then
					if self.joint.vehicleId.spec_attachable.attacherVehicle.leaveVehicle ~= nil and self.joint.vehicleId.spec_attachable.attacherVehicle.backupLeaveVehicle ~= nil then
						self.joint.vehicleId.spec_attachable.attacherVehicle.leaveVehicle = self.joint.vehicleId.spec_attachable.attacherVehicle.backupLeaveVehicle
						self.joint.vehicleId.spec_attachable.attacherVehicle.backupLeaveVehicle = nil
					end
				end
			end
		end
        removeJoint(self.joint.index);
		if self.isUsedSelf == false then
			if self.joint.vehicle.spec_enterable ~= nil and self.joint.vehicle.spec_motorized ~= nil and self.joint.vehicle.spec_wheels ~= nil then
				if not self.joint.vehicle.spec_enterable.isControlled and self.joint.vehicle.spec_motorized.motor ~= nil and self.joint.vehicle.spec_wheels.wheels~= nil then
					for k,wheel in pairs(self.joint.vehicle.spec_wheels.wheels) do
						setWheelShapeProps(wheel.node, wheel.wheelShape, 0, self.joint.vehicleId.spec_motorized.motor:getBrakeForce() * wheel.brakeFactor, 0, wheel.rotationDamping)
					end;
				end
			end;
		end
    end;
    self.joint.vehicle.forceIsActive = false;
    self.joint = nil;
    self.joint = {};
    self.isUsed = false;
	self.isUsedSelf = false
end;
function TowingChain:leaveVehicle(superFunc)
    if superFunc ~= nil then
        superFunc(self)
    end
    if self.isServer then
		if self.spec_enterable ~= nil and self.spec_motorized ~= nil and self.spec_wheels ~= nil then
			if not self.spec_enterable.isControlled and self.spec_motorized.motor ~= nil and self.spec_wheels.wheels ~= nil then
				for k, wheel in pairs(self.spec_wheels.wheels) do
					setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0, 0, wheel.rotationDamping)
				end
			end
		end
    end
end
function TowingChain:playerInRange()
	local inRange = false
	local target
	if g_currentMission.controlPlayer and g_currentMission.player ~= nil then
		target = g_currentMission.player.rootNode
	end
	if target ~= nil then
		local x,y,z = getWorldTranslation(target)
		local a,b,c = getWorldTranslation(self.attachPoint)
		local distance = MathUtil.vector3Length(x-a, y-b, z-c);
		if distance < 2.5 then
			inRange = true
		end
	end
	return inRange
end
function TowingChain:getIsTurnedOn()
    return self.attachedVehicleThrottle
end

function TowingChain:isDetachAllowed(superFunc)
    if superFunc ~= nil then
        if not superFunc(self) then
            return false
        end
    end
    return (not self.attachedVehicleThrottle and not self.isUsed)
end

function TowingChain:onDraw()
end
function TowingChain:actionCallback(actionName, keyStatus, arg4, arg5, arg6)
	if self:getIsActiveForInput() then
		if keyStatus > 0 then
			if actionName == 'TOWINGCHAIN_ATTACH_VEHICLE' then
				self.inputChainAttachVehicle = true
			elseif actionName == 'TOWINGCHAIN_MANUAL_ATTACH' then
				if not self.isUsed then
					self.inputChainManualAttach = not self.inputChainManualAttach
				end
			elseif actionName == 'TOWINGCHAIN_VEHICLE_THROTTLE' then
				self.inputChainVehicleThrottle = true
			end
		elseif keyStatus == 0 then
			if actionName == 'TOWINGCHAIN_ATTACH_VEHICLE' then
				self.inputChainAttachVehicle = false
			elseif actionName == 'TOWINGCHAIN_VEHICLE_THROTTLE' then
				self.inputChainVehicleThrottle = false
			end
		end
	end
end
function TowingChain:onReadStream(streamId, connection)
    local isUsed = streamReadBool(streamId);
    if isUsed then
        local jointId = streamReadInt32(streamId);
        local vehicleId = NetworkUtil.readNodeObject(streamId);
        TowingChain.attachObject(self, vehicleId, jointId,true);
    end;
end;
function TowingChain:onWriteStream(streamId, connection)
    streamWriteBool(streamId, self.isUsed);
    if self.isUsed then
        streamWriteInt32(streamId, self.joint.attacherJointId);
		NetworkUtil.writeNodeObject(streamId, self.joint.vehicle);
    end;
end;