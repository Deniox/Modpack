--[[
    Author: PeterAH (Modding-Welt)
    Date: September 2020
    Contact: https://www.modding-welt.com
    Discord: [MW] PeterAH#5807
]]

tireSound = {}

local _modDirectory = g_currentModDirectory

function tireSound.prerequisitesPresent(specializations)
    return true
end

function tireSound.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onPreLoad", tireSound)
    SpecializationUtil.registerEventListener(vehicleType, "onPostLoad", tireSound)
    SpecializationUtil.registerEventListener(vehicleType, "onUpdate", tireSound)
end

function tireSound:onPreLoad(savegame)
    --print("onPreLoad ===============================================================================================")	
    self.loadSounds = Utils.appendedFunction(Motorized.loadSounds, tireSound.loadSounds)
    self.startMotor = Utils.appendedFunction(Motorized.startMotor, tireSound.startMotor)
    self.stopMotor = Utils.appendedFunction(Motorized.stopMotor, tireSound.stopMotor)
end

function tireSound:loadSounds(xmlFile, motorId)
    --print(self.baseDirectory)
    --print(_modDirectory)

    if self.isClient then
        local spec = self.spec_motorized
        local baseString = "sounds"
        local sample = spec.samples
        local xmlSoundFile

        if fileExists(_modDirectory .. "sounds/tireSound.xml") then
            xmlSoundFile = loadXMLFile("tireSound", _modDirectory .. "sounds/tireSound.xml")
        else
            print("Error: Script tireSound.lua: XML-File not found: " .. _modDirectory .. "sounds/tireSound.xml")
        end
        
        if xmlSoundFile ~= nil then
            -- Adjust soundRange to the soundRange of the mod + extra distance because this sound can be heard far away
            if sample.motorStart ~= nil and sample.motorStop ~= nil then
                setXMLFloat(xmlSoundFile, "sounds.tires#innerRadius", sample.motorStart.innerRange + 3)
                setXMLFloat(xmlSoundFile, "sounds.tires#outerRadius", sample.motorStart.outerRadius + 60)
            end
            spec.samples.tires = g_soundManager:loadSampleFromXML(xmlSoundFile, baseString, "tires", _modDirectory, self.components, 0, AudioGroup.VEHICLE, self.i3dMappings, self)
            delete(xmlSoundFile)
        end

        if spec.samples.tires ~= nil then 
            self.origIndoorVolume = spec.samples.tires.indoorAttributes.volume
            self.origOutdoorVolume = spec.samples.tires.outdoorAttributes.volume

            -- Adjust pitch to the maximum tractor speed
            local maxSpeed = math.max(spec.motor.maxForwardSpeed * 3.6, 35)
            sample.tires.indoorAttributes.pitch = sample.tires.indoorAttributes.pitch * (1 + (maxSpeed - 53) / 180) * 1.35
            sample.tires.outdoorAttributes.pitch = sample.tires.outdoorAttributes.pitch * (1 + (maxSpeed - 53) / 180) * 1.35

            local SPEED = 10
            -- Overwrite pitch modifier, table[10]=SPEED
            sample.tires.modifiers.pitch[SPEED].keyframes[2].time = maxSpeed
            sample.tires.modifiers.pitch[SPEED].maxTime = maxSpeed

            -- Overwrite volume modifier, table[10]=SPEED
            sample.tires.modifiers.volume[SPEED].keyframes[1].time = (maxSpeed) * 0.55
            sample.tires.modifiers.volume[SPEED].keyframes[2].time = maxSpeed
            sample.tires.modifiers.volume[SPEED].maxTime = maxSpeed

            --for k, v in pairs(sample.tires) do
            --    print(k,v)
            --end
            --print(DebugUtil.printTableRecursively(spec.samples.tires, 0, 0, 2))
            --print(sample.tires.innerRange)
            --print(sample.tires.outerRadius)
        end
    end
end

function tireSound:onPostLoad(savegame)
    --print("onPostLoad ===============================================================================================")	
    local spec = self.spec_wheels
    local numMudTires = 0
    local numNokianTires = 0
    local numCrawler = 0
    local numTiresWithSound = 0
    local isNokianTires = false
    local isCrawler = false
    local isCareWheel = false
    local wheelsMaxWidth = 0
    
    -- How many tires with sound does the vehicle have?
    for _,wheel in pairs(spec.wheels) do
        if wheel.tireTrackAtlasIndex == 8 then
            numNokianTires = numNokianTires + 1
        elseif wheel.tireType == 4 then
            numCrawler = numCrawler + 1
        elseif wheel.tireTrackAtlasIndex == 0 or wheel.tireType == 1 then
            numMudTires = numMudTires + 1
        end
        wheelsMaxWidth = math.max(wheel.width, wheelsMaxWidth)
    end
    
    if numMudTires > 1 or numNokianTires > 1 or numCrawler > 1 then
        numTiresWithSound = numMudTires + numNokianTires + numCrawler
        if numCrawler >= numMudTires and numCrawler > 1 then
            isCrawler = true
        elseif numNokianTires >= numMudTires then
            isNokianTires = true
        end
    end
    
    if isCrawler == false and isNokianTires == false then
        if wheelsMaxWidth > 0 and wheelsMaxWidth < 0.41 then
            isCareWheel = true
        end
    end
    
    if self.origIndoorVolume == nil or self.origOutdoorVolume == nil then
        if self.isClient then
            print("Error: Script tireSound: failed, sample.tires (<tires> in the tire-sound-XML) are not loaded correctly")
        end
        numTiresWithSound = 0
    elseif self.origIndoorVolume == 0 and self.origOutdoorVolume == 0 then
        if self.isClient then
            print("Warning: Script tireSound: sample.tires (<tires> in the tire sound-XML): 0.0 (zero) for both volumes parameters")
        end
        numTiresWithSound = 0
    elseif numTiresWithSound > 0 then
        self.multiplIndoorVolume = self.origIndoorVolume / numTiresWithSound
        self.multiplOutdoorVolume = self.origOutdoorVolume / numTiresWithSound
        
        local configId = Utils.getNoNil(self.configurations["tireSound"], 1)
        local multiplierAdjust = 0
        if configId == 2 then
            multiplierAdjust = 0.4
        elseif configId == 3 then
            multiplierAdjust = 0.5
        elseif configId == 4 then
            multiplierAdjust = 0.65
        elseif configId == 5 then
            multiplierAdjust = 0.8
        elseif configId == 6 then
            multiplierAdjust = 1.0
        elseif configId == 7 then
            multiplierAdjust = 1.25
        elseif configId == 8 then
            multiplierAdjust = 1.5
        elseif configId == 9 then
            multiplierAdjust = 1.75
        elseif configId == 10 then
            multiplierAdjust = 2.0
        elseif configId == 11 then
            multiplierAdjust = 2.5
        elseif configId == 12 then
            multiplierAdjust = 3.0
        end
        self.multiplIndoorVolume = self.multiplIndoorVolume * multiplierAdjust
        self.multiplOutdoorVolume = self.multiplOutdoorVolume * multiplierAdjust

        if isNokianTires == true then
            --print("isNokianTires ===============================================================================================")	
            self.multiplIndoorVolume = self.multiplIndoorVolume * 0.5
            self.multiplOutdoorVolume = self.multiplOutdoorVolume * 0.5

            local spec = self.spec_motorized
            local maxSpeed = spec.motor.maxForwardSpeed * 3.6
            if maxSpeed > 65 then
                spec.samples.tires.indoorAttributes.pitch = spec.samples.tires.indoorAttributes.pitch * 1.10
                spec.samples.tires.outdoorAttributes.pitch = spec.samples.tires.outdoorAttributes.pitch * 1.10
            elseif maxSpeed < 45 then
                spec.samples.tires.indoorAttributes.pitch = spec.samples.tires.indoorAttributes.pitch * 70 / maxSpeed
                spec.samples.tires.outdoorAttributes.pitch = spec.samples.tires.outdoorAttributes.pitch * 70 / maxSpeed
            else
                spec.samples.tires.indoorAttributes.pitch = spec.samples.tires.indoorAttributes.pitch * 75 / maxSpeed
                spec.samples.tires.outdoorAttributes.pitch = spec.samples.tires.outdoorAttributes.pitch * 75 / maxSpeed
            end
        elseif isCrawler == true then
            --print("isCrawler ===============================================================================================")	
            self.multiplIndoorVolume = self.multiplIndoorVolume * 0.8
            self.multiplOutdoorVolume = self.multiplOutdoorVolume * 0.8
            local spec = self.spec_motorized
            spec.samples.tires.indoorAttributes.pitch = spec.samples.tires.indoorAttributes.pitch * 1.2
            spec.samples.tires.outdoorAttributes.pitch = spec.samples.tires.outdoorAttributes.pitch * 1.2
        elseif isCareWheel == true then
            --print("isCrareWheel ===============================================================================================")	
            self.multiplIndoorVolume = self.multiplIndoorVolume * 0.65
            self.multiplOutdoorVolume = self.multiplOutdoorVolume * 0.65
            local spec = self.spec_motorized
            spec.samples.tires.indoorAttributes.pitch = spec.samples.tires.indoorAttributes.pitch * 1.13
            spec.samples.tires.outdoorAttributes.pitch = spec.samples.tires.outdoorAttributes.pitch * 1.13
        end

    end    
    self.numTiresWithSound = numTiresWithSound
end

function tireSound:startMotor(noEventSend)
    local spec = self.spec_motorized
    if spec.isMotorStarted then
        if self.isClient then
            if self.numTiresWithSound > 1 then
                g_soundManager:playSample(spec.samples.tires, 0, spec.samples.motorStart)
            end
        end
    end
end

function tireSound:stopMotor(noEventSend)
    local spec = self.spec_motorized
    if not spec.isMotorStarted then
        if self.isClient then
            if self.numTiresWithSound > 1 then
                g_soundManager:stopSample(spec.samples.tires)
            end
        end
    end
end

function tireSound:onUpdate(dt)
    local spec = self.spec_wheels
    local mudTiresOnStreet = 0
    local targetIndoorVolume
    local targetOutdoorVolume
    
    if self.numTiresWithSound > 1 then
        if self:getLastSpeed() > 23 then
            
            -- How much mud tires are on the street?
            for _,wheel in pairs(spec.wheels) do
                if wheel.tireTrackAtlasIndex == 0 or wheel.tireTrackAtlasIndex == 8 or wheel.tireType == 4 or wheel.tireType == 1 then
                    local isOnField = wheel.densityType ~= 0
                    local isOnAsphalt = wheel.contact == Wheels.WHEEL_OBJ_CONTACT
                    --renderText(0.2, 0.40, 0.05,tostring(isOnAsphalt))
                    --renderText(0.2, 0.45, 0.05,tostring(wheel.lastTerrainAttribute))
                    if isOnAsphalt then
                        mudTiresOnStreet = mudTiresOnStreet + 1
                    elseif not isOnField then
                        local groundType = WheelsUtil.getGroundType(isOnField, wheel.contact ~= Wheels.WHEEL_GROUND_CONTACT, wheel.lastColor[4])
                        --renderText(0.2, 0.20, 0.05,tostring(groundType))
                        if groundType == 1 then
                            if wheel.lastTerrainAttribute == 7 then  --  7 == Concrete slabs / Betonplatten
                                mudTiresOnStreet = mudTiresOnStreet + 0.63
                            end
                        elseif groundType == 2 then  --  2 == HARD_TERRAIN
                            if wheel.lastTerrainAttribute == 1 then
                                mudTiresOnStreet = mudTiresOnStreet + 0.63
                            end
                        end
                    end
                end
            end
            
            -- Set the sound volume, dependig how much mud tires are on the street
            targetIndoorVolume = mudTiresOnStreet * self.multiplIndoorVolume
            targetOutdoorVolume = mudTiresOnStreet * self.multiplOutdoorVolume
            local sample = self.spec_motorized.samples
            if targetOutdoorVolume ~= sample.tires.outdoorAttributes.volume or targetIndoorVolume ~= sample.tires.indoorAttributes.volume then
                local smoothVolume
                if targetOutdoorVolume * 1.0001 < sample.tires.outdoorAttributes.volume then
                    sample.tires.indoorAttributes.volume = targetIndoorVolume
                    sample.tires.outdoorAttributes.volume = targetOutdoorVolume
                elseif mudTiresOnStreet < self.numTiresWithSound * 0.6 then
                    sample.tires.indoorAttributes.volume = targetIndoorVolume
                    sample.tires.outdoorAttributes.volume = targetOutdoorVolume
                else
                    smoothVolume = math.min(sample.tires.indoorAttributes.volume * 1.012, targetIndoorVolume)
                    sample.tires.indoorAttributes.volume = math.max(smoothVolume, self.multiplIndoorVolume)
                    smoothVolume = math.min(sample.tires.outdoorAttributes.volume * 1.012, targetOutdoorVolume)
                    sample.tires.outdoorAttributes.volume = math.max(smoothVolume, self.multiplOutdoorVolume)
                end
            end
            --renderText(0.2, 0.30, 0.05,tostring(self.configurations["tireSound"]))
            --renderText(0.2, 0.25, 0.05,tostring(sample.tires.outdoorAttributes.volume))
        end
    end
end
