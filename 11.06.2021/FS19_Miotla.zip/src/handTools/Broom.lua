--─────────────────────███───────────────────────────────────────────────────────────────────────────────███───-
--────────────────────█───█─────────────────────────────────────────────────────────────────────────────█───█──-
--───────────────────█─────█────────────╔═══╗─────────╔═╗╔═╗────╔╗─────────────────────────────────────█─────█─-
--──────────────────█─────█─────────────╚╗╔╗║─────────║║╚╝║║────║║────────────────────────────────────█─────█──-
--─────────────────█──────█──────────────║║║╠══╦═╗╔╦══╣╔╗╔╗╠══╦═╝╠══╗────────────────────────────────█──────█──-
--──────────███────█─────█───────────────║║║║╔╗║╔╗╬╣╔╗║║║║║║╔╗║╔╗║══╣─────────────────────────███────█─────█───-
--────────██───██─█─────█───────────────╔╝╚╝║╔╗║║║║║╚╝║║║║║║╚╝║╚╝╠══║───────────────────────██───██─█─────█────-
--───────█──█────██─────█───────────────╚═══╩╝╚╩╝╚╩╩══╩╝╚╝╚╩══╩══╩══╝──────────────────────█──█────██─────█────-
--─────██──█──────█────█───────╔═╗╔═╗────╔╗──────────╔╗╔╗────────────────────────────────██──█──────█────█─────-
--────█───█───────██───█───────║║╚╝║║────║║─────────╔╝╚╣║───────────────────────────────█───█───────██───█─────-
--───█────█────────█───█───────║╔╗╔╗╠══╦═╝╠══╗╔╗╔╗╔╦╬╗╔╣╚═╗╔══╦══╦══╦══╦╦══╦═╗─────────█────█────────█───█─────-
--───█─────█────────█───█──────║║║║║║╔╗║╔╗║║═╣║╚╝╚╝╠╣║║║╔╗║║╔╗║╔╗║══╣══╬╣╔╗║╔╗╗────────█─────█────────█───█────-
--───█──█───█────────█──█──────║║║║║║╔╗║╚╝║║═╣╚╗╔╗╔╣║║╚╣║║║║╚╝║╔╗╠══╠══║║╚╝║║║║────────█──█───█────────█──█────-
--──█───█────██──────█──█──────╚╝╚╝╚╩╝╚╩══╩══╝─╚╝╚╝╚╝╚═╩╝╚╝║╔═╩╝╚╩══╩══╩╩══╩╝╚╝───────█───█────██──────█──█────-
--──█────█─────██───█───█──────────────────────────────────║║─────────────────────────█────█─────██───█───█────-
--──█─█───█──────███────█──────────────────────────────────╚╝─────────────────────────█─█───█──────███────█────-
--─█───█───██─────█─────█────────────────────────────────────────────────────────────█───█───██─────█─────█────-
--─█────█────█████─────█────────────────────Date: 01.03.2021─────────────────────────█────█────█████─────█─────-
--─█─────█───────█─────█──────Copyright (C): DanioMods, All Rights Reserved──────────█─────█───────█─────█─────-
--─█─█────██────█─────█──────────────Broom hand tool specialization──────────────────█─█────██────█─────█──────-
--──█─█─────████────██────────────────Version: Farming Simulator 19───────────────────█─█─────████────██───────-
--──█──█───────█──██─█────────────────────────────────────────────────────────────────█──█───────█──██─█───────-
--───█──██───██──█───█─────────────────────────────────────────────────────────────────█──██───██──█───█───────-
--────██──███──██─█──█──────────────────────────────────────────────────────────────────██──███──██─█──█───────-
--─────██───███───█───█──────────────────────────────────────────────────────────────────██───███───█───█──────-
--───────███──────█───█────────────────────────────────────────────────────────────────────███──────█───█──────-
--───────█────────█───█────────────────────────────────────────────────────────────────────█────────█───█──────-
--───────█────────────█────────────────────────────────────────────────────────────────────█────────────█──────-
--───────█─────────────█───────────────────────────────────────────────────────────────────█─────────────█─────-
--───────█─────────────█───────────────────────────────────────────────────────────────────█─────────────█─────-
--─────────────────────────────────────────────────────────────────────────────────────────────────────────────-

-- !! PROHIBITION OF ANY EDITING, COPYING, DUPLICATION OR USE !! --
-- !! VERBOT JEDER BEARBEITUNG, KOPIERUNG, DUPLIZIERUNG ODER VERWENDUNG !! --
-- !! INTERDICTION DE TOUTE ÉDITION, COPIE, DUPLICATION OU UTILISATION !! --
-- !! ЗАПРЕТ ЛЮБОГО РЕДАКТИРОВАНИЯ, КОПИРОВАНИЯ, ДУБЛИКАЦИИ ИЛИ ИСПОЛЬЗОВАНИЯ !! --
-- !! DRAUDIMAS JOKIAM REDAGAVIMUI, KOPIJUOTI, DAUGINTI ARBA NAUDOTI !! --
-- !! ZÁKAZ AKÉKOĽVEK ÚPRAVY, KOPÍROVANIA, DUPLIKÁCIE ALEBO POUŽITIA !! --
-- !! DIVIETO DI QUALSIASI MODIFICA, COPIA, DUPLICAZIONE O UTILIZZO !! --
-- !! ZAKAZ JAKICHKOLWIEK EDYCJI, KOPIOWANIA, POWIELANIA LUB UŻYWANIA !! --

Broom = {}

if g_modIsLoaded["FS19_3rdPerson"] then
	Broom.cameraChangeOff = _G["FS19_3rdPerson"].thirdPerson
end;

local Broom_mt = Class(Broom, HandTool)

InitObjectClass(Broom, "Broom")

function Broom:new(isServer, isClient, customMt)
	local self = HandTool:new(isServer, isClient, customMt or Broom_mt)
	return self
end;

function Broom:load(xmlFilename, player)
	if not Broom:superClass().load(self, xmlFilename, player) then
		return false
	end;
	
	local xmlFile = loadXMLFile("TempXML", xmlFilename)
	
	self.activatePressed = false
	if self.isClient then
		
		self.samples = {
			randomSoundOne = g_soundManager:loadSampleFromXML(xmlFile, "handTool.broom.sounds" , "randomSoundOne", self.baseDirectory, self.rootNode, 1, AudioGroup.VEHICLE, nil, nil),
			randomSoundTwo = g_soundManager:loadSampleFromXML(xmlFile, "handTool.broom.sounds" , "randomSoundTwo", self.baseDirectory, self.rootNode, 1, AudioGroup.VEHICLE, nil, nil),
			randomSoundThree = g_soundManager:loadSampleFromXML(xmlFile, "handTool.broom.sounds" , "randomSoundThree", self.baseDirectory, self.rootNode, 1, AudioGroup.VEHICLE, nil, nil)
		}
		
		self.workAreas = {
			startNode = I3DUtil.indexToObject(self.rootNode, getXMLString(xmlFile, "handTool.broom.workAreas.broomArea#startNode")),
			widthNode = I3DUtil.indexToObject(self.rootNode, getXMLString(xmlFile, "handTool.broom.workAreas.broomArea#widthNode")),
			heightNode = I3DUtil.indexToObject(self.rootNode, getXMLString(xmlFile, "handTool.broom.workAreas.broomArea#heightNode"))
		}
		
		self.effects = g_effectManager:loadEffect(xmlFile, "handTool.broom.effects", self.rootNode, self)
		
		self.showNotOwnedWarning = false
		self.isWorking = false
		self.foliageBendingNode = I3DUtil.indexToObject(self.rootNode, getXMLString(xmlFile, "handTool.broom#foliageBendingNode"))
		self.broomFoliageNode = createTransformGroup("broomFoliageNode")
		link(self.foliageBendingNode, self.broomFoliageNode)
		
		self.animationNode = I3DUtil.indexToObject(self.rootNode, getXMLString(xmlFile, "handTool.broom.broomAnimation#node"))
		if self.animationNode ~= nil then
			local animKey = "handTool.broom.broomAnimation"
			
			self.broomAnimation = {part ={}}
			self.broomAnimation.duration = Utils.getNoNil(getXMLFloat(xmlFile, animKey .. "#duration"), 4) * 1000
			
			if self.broomAnimation.duration == 0 then
				self.broomAnimation.duration = 1000
			end;
			
			self.broomAnimation.time = 0
			self.broomAnimation.part.animCurve = AnimCurve:new(linearInterpolatorN)
			local a = 0
			
			while true do 
				local key2 = string.format("%s.keyFrame(%d)", animKey, a)
				
				if not hasXMLProperty(xmlFile, key2) then
					break
				end;
				
				local keyTime = getXMLFloat(xmlFile, key2 .. "#time")
				local keyFrame = {time = keyTime}
				local bx, by, bz = StringUtil.getVectorFromString(getXMLString(xmlFile, key2 .. "#translation"))
				local cx, cy, cz = StringUtil.getVectorFromString(getXMLString(xmlFile, key2 .. "#rotation"))
				local dx, dy, dz = StringUtil.getVectorFromString(getXMLString(xmlFile, key2 .. "#scale"))
				
				local ex, ey, ez = getTranslation(self.animationNode)
				keyFrame[1] = Utils.getNoNil(bx, ex)
				keyFrame[2] = Utils.getNoNil(by, ey)
				keyFrame[3] = Utils.getNoNil(bz, ez)
				
				local fx, fy, fz = getRotation(self.animationNode)
				keyFrame[4] = Utils.getNoNilRad(cx, fx)
				keyFrame[5] = Utils.getNoNilRad(cy, fy)
				keyFrame[6] = Utils.getNoNilRad(cz, fz)
				
				local gx, gy, gz = getScale(self.animationNode)
				keyFrame[7] = Utils.getNoNil(dx, gx)
				keyFrame[8] = Utils.getNoNil(dy, gy)
				keyFrame[9] = Utils.getNoNil(dz, gz)
				
				self.broomAnimation.part.animCurve:addKeyframe(keyFrame)
				
				a = a + 1
			end;
		end;
		self.animCurrentTime = 0
	end;
	
	delete(xmlFile)
	
	return true
end;

function Broom:update(dt, allowInput)
	Broom:superClass().update(self, dt, allowInput)
	if self.isClient then
		self.player.rotX = self.player.rotX - self.player.inputInformation.pitchCamera * g_gameSettings:getValue(GameSettings.SETTING.CAMERA_SENSITIVITY)
		self.player.rotY = self.player.rotY - self.player.inputInformation.yawCamera * g_gameSettings:getValue(GameSettings.SETTING.CAMERA_SENSITIVITY)
		self.player.rotX = math.min(0.05, math.max(-0.6, self.player.rotX))
		setRotation(self.player.cameraNode, self.player.rotX, self.player.rotY, 0)
		if allowInput then
			if self.activatePressed then
				if self.broomAnimation.time == 1 then
					self.broomAnimation.time = 0
				end;
				if self.player.rotX > -0.6 then
					self.player.rotX = self.player.rotX - (dt / 800)
				end;
				g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.AXIS_LOOK_UPDOWN_PLAYER].eventId, false)
				local canUse = self:getCanAccessToUse()
				
				if canUse then
					self.animCurrentTime = self:setBroomAnimationTime(self.broomAnimation.time + dt / self.broomAnimation.duration)
					if self.broomAnimation.time <= 0.35 and self.broomAnimation.time >= 0.2 then
						local hx, _, hz = getWorldTranslation(self.workAreas.startNode)
						local ix, _, iz = getWorldTranslation(self.workAreas.widthNode)
						local jx, _, jz = getWorldTranslation(self.workAreas.heightNode)
						
						DensityMapHeightUtil.clearArea(hx, hz, ix, iz, jx, jz)
						self:playBroomSounds()
						self.isWorking = true
						self.player.motionInformation.maxWalkingSpeed = 1
						g_effectManager:setFillType(self.effects, FillType.WHEAT)
						g_effectManager:startEffects(self.effects)
					end;
				end;
			else
				self.isWorking = false
				self.player.motionInformation.maxWalkingSpeed = 4
				self.animCurrentTime = math.max(self.animCurrentTime - dt/1000, 0)
				if self.broomAnimation.time > 0.35 then
					self:setBroomAnimationTime(self.broomAnimation.time + dt / self.broomAnimation.duration)
				else
					self:setBroomAnimationTime(self.animCurrentTime)
				end;
				g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.AXIS_LOOK_UPDOWN_PLAYER].eventId, true)
				g_effectManager:stopEffects(self.effects)
			end;
		end;
	end;
	self.activatePressed = false
	if Broom.cameraChangeOff ~= nil then
		if Broom.cameraChangeOff.isActive then
			Broom.cameraChangeOff:setVisibility(self.player, false)
			Broom.cameraChangeOff:resetFlashLight(self.player)
			Broom.cameraChangeOff.camWasTP = false
			Broom.cameraChangeOff.isActive = false
			setCamera(self.player.cameraNode)
		end;
	end;
end;

function Broom:getCanAccessToUse()
	local kx, _, kz = getWorldTranslation(self.foliageBendingNode)
	local farmId = g_currentMission:getFarmId()
	local isFarmLandOwned = g_currentMission.accessHandler:canFarmAccessLand(farmId, kx, kz)
	
	if isFarmLandOwned then
		return true
	else
		self.showNotOwnedWarning = true
		return false
	end;
end;

function Broom:playBroomSounds()
	if not g_soundManager:getIsSamplePlaying(self.samples.randomSoundOne) and not g_soundManager:getIsSamplePlaying(self.samples.randomSoundTwo) and not g_soundManager:getIsSamplePlaying(self.samples.randomSoundThree) then
		local draw = math.random(1, 2, 3)
		
		if draw == 1 then
			g_soundManager:playSample(self.samples.randomSoundOne)
		elseif draw == 2 then
			g_soundManager:playSample(self.samples.randomSoundTwo)
		elseif draw == 3 then
			g_soundManager:playSample(self.samples.randomSoundThree)
		end;
	end;
end;

function Broom:setBroomAnimationTime(currentTime)
	local currentTime = MathUtil.clamp(currentTime, 0, 1)
	local v = self.broomAnimation.part.animCurve:get(currentTime)
	
	setTranslation(self.animationNode, v[1], v[2], v[3])
	setRotation(self.animationNode, v[4], v[5], v[6])
	setScale(self.animationNode, v[7], v[8], v[9])
	
	self.broomAnimation.time = currentTime
	
	return currentTime
end;

function Broom:onActivate(allowInput)
	Broom:superClass().onActivate(self)
	
	if self.isClient then
		if self.broomFoliageNode ~= nil and self.foliageBendingNodeId == nil then
			self.foliageBendingNodeId = g_currentMission.foliageBendingSystem:createRectangle(-0.3, 0.3, -1, 1, 0.6, self.broomFoliageNode)
		end;
		g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.CROUCH].eventId, false)
		g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.JUMP].eventId, false)
	end;
end;

function Broom:onDeactivate(allowInput)
	Broom:superClass().onDeactivate(self)
	
	if self.isClient then
		if self.foliageBendingNodeId ~= nil then
			g_currentMission.foliageBendingSystem:destroyObject(self.foliageBendingNodeId)
			self.foliageBendingNodeId = nil
		end;
		self.player.motionInformation.maxWalkingSpeed = 4
		g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.CROUCH].eventId, true)
		g_inputBinding:setActionEventActive(self.player.inputInformation.registrationList[InputAction.JUMP].eventId, true)
	end;
end;

function Broom:draw()
	Broom:superClass().draw(self)
	
	local warning = self.showNotOwnedWarning
	
	if self.isClient then
		if warning then
			g_currentMission:showBlinkingWarning(g_i18n:getText("warning_youDontHaveAccessToThisLand"), 2000)
		end;
	end;
end;

function Broom:delete()
	if self.isClient then
		if self.foliageBendingNodeId ~= nil then
			g_currentMission.foliageBendingSystem:destroyObject(self.foliageBendingNodeId)
			self.foliageBendingNodeId = nil
		end;
		g_soundManager:deleteSamples(self.samples)
	end;
	
	Broom:superClass().delete(self)
end;

registerHandTool("broom", Broom)