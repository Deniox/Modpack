Sklep={}
Sklep.Otwarty = 7
Sklep.Zamkniety = 23

function Sklep:update(dt)
	if not ( g_currentMission.environment.currentHour >= Sklep.Otwarty and g_currentMission.environment.currentHour < Sklep.Zamkniety ) then
	g_currentMission:addExtraPrintText("Sklep jest zamknięty.")
	if g_gui.currentGui == g_gui.guis.ShopMenu then
            g_gui:showGui("")
        end
	else
		g_currentMission:addExtraPrintText("Sklep jest Otwarty.")
    end
end

addModEventListener(Sklep)