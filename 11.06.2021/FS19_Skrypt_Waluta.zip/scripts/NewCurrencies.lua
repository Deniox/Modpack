---
-- NewCurrencies
--
-- Author: Rockstar
-- Version: 1.0.0.0
-- Date: 10.02.2021
--

NewCurrencies = {}
NewCurrencies.MOD_DIRECTORY = g_currentModDirectory
NewCurrencies.MOD_NAME = g_currentModName

function NewCurrencies:loadMap(filename)
	local currencies, texts, useConverter = self:loadCurrenciesFromXMLFile(Utils.getFilename("xml/currencies.xml", NewCurrencies.MOD_DIRECTORY), g_settingsScreen.settingsModel:getMoneyUnitTexts())

	local pageSettingsGeneral = g_currentMission.inGameMenu.pageSettingsGeneral
	local moneyUnitElement = pageSettingsGeneral.multiMoneyUnit
	local gameInfoDisplay = g_currentMission.hud.gameInfoDisplay
	local i18n = getfenv(0).g_i18n

	moneyUnitElement.onClickCallback = Utils.overwrittenFunction(moneyUnitElement.onClickCallback, self.onClickCallback)
	gameInfoDisplay.setMoneyUnit = Utils.overwrittenFunction(gameInfoDisplay.setMoneyUnit, self.setMoneyUnit)
	i18n.getCurrencySymbol = Utils.overwrittenFunction(i18n.getCurrencySymbol, self.getCurrencySymbol)
	i18n.formatMoney = Utils.overwrittenFunction(i18n.formatMoney, self.formatMoney)

	FSCareerMissionInfo.saveToXMLFile = Utils.appendedFunction(FSCareerMissionInfo.saveToXMLFile, self.saveToXMLFile)

	moneyUnitElement:setTexts(texts)
	moneyUnitElement:setState(g_gameSettings:getValue(GameSettings.SETTING.MONEY_UNIT))
	pageSettingsGeneral.optionMapping[moneyUnitElement] = nil

	self.currencies = currencies
	self.useConverter = useConverter

	local state = self:loadFromXMLFile()

	if state ~= nil then
		g_currentMission:setMoneyUnit(state)
		moneyUnitElement:setState(state)
	end
end

function NewCurrencies:loadCurrenciesFromXMLFile(xmlFilename, baseTexts)
	local currencies = {}
	local texts = baseTexts
	local useConverter = false

	local xmlFile = loadXMLFile("currenciesXMLFile", xmlFilename)

	if xmlFile ~= nil then
		local imageFilename = getXMLString(xmlFile, "currencies#imageFilename")
		if imageFilename ~= nil then
			self.imageFilename = NewCurrencies.MOD_DIRECTORY .. imageFilename
		end

		useConverter = getXMLBool(xmlFile, "currencies#useConverter")

		local i = 0

		while true do
			local key = string.format("currencies.currency(%d)", i)
			if not hasXMLProperty(xmlFile, key) then
				break
			end

			local unit = XMLUtil.getXMLI18NValue(xmlFile, key .. "#text", getXMLString, nil, "", NewCurrencies.MOD_NAME, true)
			local unitShort = XMLUtil.getXMLI18NValue(xmlFile, key .. "#textShort", getXMLString, nil, "", NewCurrencies.MOD_NAME, true)
			local prefix = Utils.getNoNil(getXMLBool(xmlFile, key .. "#prefixSymbol"), true)
			local factor = Utils.getNoNil(getXMLFloat(xmlFile, key .. "#factor"), 1)
			local a, b, c, d = StringUtil.getVectorFromString(Utils.getNoNil(getXMLString(xmlFile, key .. "#imageUVs"), "0 0 0 0"))

			table.insert(texts, unit)
			table.insert(currencies, {unit = unit, unitShort = unitShort, prefix = prefix, factor = factor, uvs = {a, b, c, d}})

			i = i + 1
		end

		delete(xmlFile)
	end

	return currencies, texts, useConverter
end

function NewCurrencies:onClickCallback(superFunc, state, checkboxElement)
	g_currentMission:setMoneyUnit(state)
end

function NewCurrencies:getCurrencySymbol(superFunc, useShort)
	if self.moneyUnit > 3 then
		local currency = NewCurrencies.currencies[self.moneyUnit - 3]
		local text = currency.unit

		if useShort then
			text = currency.unitShort
		end

		return text
	else
		return superFunc(self, useShort)
	end
end

function NewCurrencies:setMoneyUnit(superFunc, moneyUnit)
	self.moneyUnit = moneyUnit

	local pixelUVs, refSize = GameInfoDisplay.UV.MONEY_ICON[moneyUnit], {1024, 1024}
	local overlayFilename = g_baseHUDFilename

	if moneyUnit > 3 then
		overlayFilename = Utils.getNoNil(NewCurrencies.imageFilename, overlayFilename)
		pixelUVs, refSize = NewCurrencies.currencies[self.moneyUnit - 3].uvs, {256, 256}
	end

	self.moneyIconOverlay:setImage(overlayFilename)
	self.moneyIconOverlay:setUVs(getNormalizedUVs(pixelUVs, refSize))
end

function NewCurrencies:formatMoney(superFunc, number, precision, addCurrency, prefixCurrencySymbol)
	if self.moneyUnit > 3 and (addCurrency == nil or addCurrency) then
		prefixCurrencySymbol = NewCurrencies.currencies[self.moneyUnit - 3].prefix
	end

	if NewCurrencies.useConverter then
		local factor = 1.34

		if self.moneyUnit == GS_MONEY_EURO then
			factor = 1
		elseif self.moneyUnit == GS_MONEY_POUND then
			factor = 0.79
		end

		if self.moneyUnit > 3 then
			factor = NewCurrencies.currencies[self.moneyUnit - 3].factor
		end

		number = number * factor
	end

	return superFunc(self, number, precision, addCurrency, prefixCurrencySymbol)
end

function NewCurrencies:saveToXMLFile()
	local currencyXMLFile = createXMLFile("currencyXMLFile", g_currentMission.missionInfo.savegameDirectory .. "/currency.xml", "currency")

	if currencyXMLFile ~= nil then
		setXMLInt(currencyXMLFile, "currency", g_i18n.moneyUnit)

		saveXMLFile(currencyXMLFile)
		delete(currencyXMLFile)
	end
end

function NewCurrencies:loadFromXMLFile()
	local state = nil

	if g_currentMission.missionInfo.savegameDirectory ~= nil then
		local xmlFilename = g_currentMission.missionInfo.savegameDirectory .. "/currency.xml"

		if fileExists(xmlFilename) then
			local xmlFile = loadXMLFile("currencyXMLFile", xmlFilename)
			if xmlFile ~= nil then
				local currency = getXMLInt(xmlFile, "currency")

				if currency ~= nil and currency > 3 then
					state = currency
				end

				delete(xmlFile)
			end
		end
	end

	return state
end

addModEventListener(NewCurrencies)