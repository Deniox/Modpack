-- 	GreenMowingForageWagon Script
--
-- 	Author: 	Silas770
-- 	Date:		30.04.2020
--	Version:	1.0.0.0 (FS19)
--

GreenMowingForageWagon = {};

function GreenMowingForageWagon.prerequisitesPresent()
    return true;
end;

function GreenMowingForageWagon.registerOverwrittenFunctions(vehicleType)
    SpecializationUtil.registerOverwrittenFunction(vehicleType, "processForageWagonArea", GreenMowingForageWagon.processForageWagonArea)
end;

-- !!! Credit to Realismus Modding !!!
-- Treat chaff and wcs as the same
function GreenMowingForageWagon.processForageWagonArea(vehicle, superFunc, workArea)
    -- When picking things up, always grab both chaff and wcs (treat them as the same thing)
    local oldTip = DensityMapHeightUtil.tipToGroundAroundLine;
    DensityMapHeightUtil.tipToGroundAroundLine = function(vehicle, delta, fillTypeIndex, ...)
        local dropped, lineOffset = oldTip(vehicle, delta, fillTypeIndex, ...);

        -- If request is chaff also pick up wcs
        if FillType.WCS_WINDROW ~= nil and fillTypeIndex == FillType.CHAFF then
            local dropped2, lineOffset2 = oldTip(vehicle, delta, FillType.WCS_WINDROW, ...);

            dropped = dropped + dropped2;
            lineOffset = lineOffset + lineOffset2;
        end;

        return dropped, lineOffset;
    end;

    local realArea, area = superFunc(vehicle, workArea);

    DensityMapHeightUtil.tipToGroundAroundLine = oldTip;

    return realArea, area;
end;
