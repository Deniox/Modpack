-- 	GreenMowingMower Script
--
-- 	Author: 	Silas770
-- 	Date:		03.05.2020
--	Version:	1.0.0.0 (FS19)
--

local function loadedMission(mission, node)
    if mission.cancelLoading then
        return;
    end;

    local overwriteMowerConverter = Utils.getNoNil(getXMLBool(mission.xmlFile, "map.greenMowing#overwriteMowerConverter"), true);
    if not overwriteMowerConverter then
        return;
    end;

    -- overwrite fruitType converter of mower
    local converter = g_fruitTypeManager.nameToConverter["MOWER"];

    local fruitTypes = { FruitType.WHEAT, FruitType.BARLEY, FruitType.OAT, FruitType.RYE, FruitType.TRITICALE };
    for _, fruitType in pairs(fruitTypes) do
        if fruitType ~= nil and converter[fruitType] ~= nil then
            converter[fruitType].fillTypeIndex = FillType.GRASS_WINDROW;
        end;
    end;
end;

Mission00.loadMission00Finished = Utils.appendedFunction(Mission00.loadMission00Finished, loadedMission);
