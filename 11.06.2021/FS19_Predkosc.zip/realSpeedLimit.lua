----------------------------------------------------------------------------
-- @Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------
----------------------------------------------------------------------------

realSpeedLimit = {};
real_SpeedLimit = {};
realSpeedLimit.modDirectory  = g_currentModDirectory;
local modDescFile = loadXMLFile("modDesc", realSpeedLimit.modDirectory .. "modDesc.xml");
realSpeedLimit.title = getXMLString(modDescFile, "modDesc.title.en");
realSpeedLimit.author = getXMLString(modDescFile, "modDesc.author");
realSpeedLimit.version = getXMLString(modDescFile, "modDesc.version");
delete(modDescFile);

function realSpeedLimit.prerequisitesPresent(specializations)
	return SpecializationUtil.hasSpecialization(Washable, specializations)
		and SpecializationUtil.hasSpecialization(Motorized, specializations);
end;

function realSpeedLimit.registerEventListeners(vehicleType)
	SpecializationUtil.registerEventListener(vehicleType, "onLeaveVehicle", realSpeedLimit);
	SpecializationUtil.registerEventListener(vehicleType, "onRegisterActionEvents", realSpeedLimit);
	SpecializationUtil.registerEventListener(vehicleType, "onLoad", realSpeedLimit);
	SpecializationUtil.registerEventListener(vehicleType, "onUpdate", realSpeedLimit);
	SpecializationUtil.registerEventListener(vehicleType, "onDraw", realSpeedLimit);
end;

function realSpeedLimit:getSpeedLimit(superFunc, onlyIfWorking)
    local limit = math.huge;
    local doCheckSpeedLimit = self:doCheckSpeedLimit();
    if onlyIfWorking == nil or (onlyIfWorking and doCheckSpeedLimit) then
		if not self.realSpeedLimitActive then
			limit = self.speedLimit;
        end;
        local damage = self:getVehicleDamage();
        if damage > 0 then
            limit = limit * (1 - damage * Vehicle.DAMAGED_SPEEDLIMIT_REDUCTION);
        end;
    end;

	if not self.realSpeedLimitActive then
		local attachedImplements;
		if self.getAttachedImplements ~= nil then
			attachedImplements = self:getAttachedImplements();
		end;
		if attachedImplements ~= nil then
			for _, implement in pairs(attachedImplements) do
				if implement.object ~= nil then
					local speed, implementDoCheckSpeedLimit = implement.object:getSpeedLimit(onlyIfWorking);
					if onlyIfWorking == nil or (onlyIfWorking and implementDoCheckSpeedLimit) then
						limit = math.min(limit, speed);
					end;
					doCheckSpeedLimit = doCheckSpeedLimit or implementDoCheckSpeedLimit;
				end;
			end;
		end;
	end;

    return limit, doCheckSpeedLimit;
end;

function realSpeedLimit:onLoad()
	self.realSpeedLimitActive = false;
	self.realSpeedLimitEvents = {};
	self.realSpeedLimitEventIds = {};
end;

function realSpeedLimit:onLeaveVehicle()
	realSpeedLimit.suggestedLimit = nil;
end;

function realSpeedLimit:toggleActive()
	self.realSpeedLimitActive = not self.realSpeedLimitActive;
	if not self.realSpeedLimitActive then
		realSpeedLimit.suggestedLimit = nil;
	end;
end;

function realSpeedLimit:getAttachedSpeedLimit(self)
    local limit = math.huge;
	if self.speedLimit ~= nil then
		limit = self.speedLimit;
		local attachedImplements;
		if self.getAttachedImplements ~= nil then
			attachedImplements = self:getAttachedImplements();
		end;
		if attachedImplements ~= nil then
			for _, implement in pairs(attachedImplements) do
				if implement.object ~= nil then
					limit = math.min(limit, realSpeedLimit:getAttachedSpeedLimit(implement.object));
				end;
			end;
		end;
	end;
	return limit;
end;

function realSpeedLimit:onUpdate(dt)
	if self.realSpeedLimitActive then
		if self == g_currentMission.controlledVehicle then
			local suggestedLimit = realSpeedLimit:getAttachedSpeedLimit(self);
			if suggestedLimit < 100 then
				realSpeedLimit.suggestedLimit = suggestedLimit;
			end;
		end;
	end;
end;

function realSpeedLimit:onDraw(dt)
	if self.realSpeedLimitActive then
		if realSpeedLimit.suggestedLimit ~= nil then
			local speed = tostring(realSpeedLimit.suggestedLimit);
			g_currentMission:addExtraPrintText("Suggested Working Speed: "..speed);
		end;
	end;
end;

function realSpeedLimit:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
	if self.isClient then
		self:clearActionEventsTable(self.realSpeedLimitEvents);
		self.realSpeedLimitEventIds = {};		
        if self:getIsActiveForInput(true, true) then
			local _, actionEventId = self:addActionEvent(self.realSpeedLimitEvents, 'realSpeedLimit_toggleKey', self, realSpeedLimit.toggleActive, false, true, false, true, nil);
			g_inputBinding:setActionEventTextVisibility(actionEventId, true);
			g_inputBinding:setActionEventTextPriority(actionEventId, GS_PRIO_HIGH);
			table.insert(self.realSpeedLimitEventIds, actionEventId);
			if actionEventId == "" then
				_, actionEventId = self:addActionEvent(self.realSpeedLimitEvents, 'realSpeedLimit_toggleKey', self, realSpeedLimit.toggleActive, false, true, false, true, nil);
				g_inputBinding:setActionEventTextVisibility(actionEventId, true);
				g_inputBinding:setActionEventTextPriority(actionEventId, GS_PRIO_HIGH);
				table.insert(self.realSpeedLimitEventIds, actionEventId);
			end;
		end;
	end;
end;

Vehicle.getSpeedLimit = Utils.overwrittenFunction(Vehicle.getSpeedLimit, realSpeedLimit.getSpeedLimit);
print("Load mod: "..realSpeedLimit.title.." : v"..realSpeedLimit.version.." by "..realSpeedLimit.author);