----------------------------------------------------------------------------
-- @Author: ViperGTS96------------------------------------------------------
----------------------------------------------------------------------------
--------------------"The simplest design is the best design." --------------
----------------------------------------------------------------------------
----------------------------------------------------------------------------

source(Utils.getFilename("realSpeedLimit.lua", g_currentModDirectory));

realSpeedLimitRegister = {};

function installSpec()
	if g_specializationManager:getSpecializationByName("realSpeedLimit") == nil then
		if realSpeedLimit == nil then 
			print("ERROR: unable to find source file 'realSpeedLimit'");
		else 
			for typeName, typeDef in pairs(g_vehicleTypeManager.vehicleTypes) do
				if typeDef ~= nil and (typeName ~= "locomotive") then 
					local isWashable = false;
					local hasEngine = false;
					for name, spec in pairs(typeDef.specializationsByName) do
						if name == "washable" then 
							isWashable = true;
						elseif name == "motorized" then 
							hasEngine = true;
						end;
					end;
					if isWashable and hasEngine then
						typeDef.specializationsByName["realSpeedLimit"] = realSpeedLimit;
						table.insert(typeDef.specializationNames, "realSpeedLimit");
						table.insert(typeDef.specializations, realSpeedLimit);
					end;
				end;
			end;
		end;	
	end;
end;

VehicleTypeManager.validateVehicleTypes = Utils.prependedFunction(VehicleTypeManager.validateVehicleTypes, installSpec);