Godzina = {}
Godzina.configFileName = "Godzina.xml"
Godzina.d = {};
Godzina.d.timeFormat = "%H:%M  |  %d.%m.%Y"
Godzina.d.position = {}
Godzina.d.position.dynamic = true
Godzina.d.position.x = 1
Godzina.d.position.y = 1
Godzina.d.rendering = {}
Godzina.d.rendering.color = "white"
Godzina.d.rendering.fontSize = 0.018

local function protect(tbl)
  return setmetatable({}, {
    __index = tbl,
    __newindex = function(t, key, value)
      error("attempting to change constant " ..
        tostring(key) .. " to " .. tostring(value), 2)
    end
  })
end

Godzina.d = protect(Godzina.d)

function Godzina:loadMap(name)
  self.debugger = Debug:create("Godzina")
  self.debugger:setLogLvl(Debug.INFO)

  self.debugger:info("Godzina Zaladowany")

  self.position = {}
  self.position.dynamic = Godzina.d.position.dynamic
  self.position.x = Godzina.d.position.x
  self.position.y = Godzina.d.position.y
  self.rendering = {}
  self.rendering.color = Godzina.d.rendering.color
  self.rendering.fontSize = Godzina.d.rendering.fontSize
  self.timeFormat = Godzina.d.timeFormat

  if g_dedicatedServerInfo == nil then
    local xmlFile = g_modsDirectory .. "/" .. Godzina.configFileName;
    if not fileExists(xmlFile) then
      self:writeDefaultConfig(xmlFile);
    else
      self:setValuesFromXML(xmlFile);
    end
  end
end

function Godzina:deleteMap()
end

function Godzina:mouseEvent(posX, posY, isDown, isUp, button)
end

function Godzina:keyEvent(unicode, sym, modifier, isDown)
end

function Godzina:update(dt)
end

function Godzina:draw()
  if g_dedicatedServerInfo ~= nil or not g_currentMission.renderTime then
    return
  end

  local r, g, b, a = self:getColor(self.rendering.color)
  setTextColor(r, g, b, a)
  local fontSize = g_gameSettings:getValue("uiScale") * self.rendering.fontSize
  local date = getDate(self.timeFormat)
  local posX = self.position.x
  local posY = self.position.y
  if self.position.dynamic then
    local width = getTextWidth(fontSize, date)
    local height = getTextHeight(fontSize, date)
    posX = 0.99 - width
    posY = 1 - height
  end
  renderText(posX, posY, fontSize, date)
  setTextColor(1, 1, 1, 1)
end

function Godzina:getColor(source)
  local color = source:lower()
  if color == "white" then
    return 1, 1, 1, 1
  elseif color == "black" then
    return 0, 0, 0, 1
  else
    local splitted = Utils.splitString(",", color)
    local colors = {}
    for _, v in pairs(splitted) do
      table.insert(colors, tonumber(v))
    end
    return unpack(colors)
  end
end

function Godzina:writeDefaultConfig(fileName)
  self.debugger:info(function()
    return "Write default Config to " .. fileName
  end)
  local xml = createXMLFile("Godzina", fileName, "Godzina");
  setXMLBool(xml, "Godzina.position#isDynamic", Godzina.d.position.dynamic)
  setXMLFloat(xml, "Godzina.position#x", Godzina.d.position.x)
  setXMLFloat(xml, "Godzina.position#y", Godzina.d.position.y)
  setXMLString(xml, "Godzina.rendering#color", Godzina.d.rendering.color)
  setXMLFloat(xml, "Godzina.rendering#fontSize", Godzina.d.rendering.fontSize)
  setXMLString(xml, "Godzina.format#string", Godzina.d.timeFormat)
  saveXMLFile(xml)
  delete(xml)
end

function Godzina:setValuesFromXML(fileName)
  self.debugger:info(function()
    return "Read from xml " .. fileName
  end)
  local xml = loadXMLFile("Godzina", fileName)
  self.position.dynamic = Utils.getNoNil(getXMLBool(xml, "Godzina.position#isDynamic"), Godzina.d.position.dynamic);
  local x = Utils.getNoNil(getXMLFloat(xml, "Godzina.position#x"), Godzina.d.position.x)
  if (self:validateFloat(x, "x")) then
    self.rendering.x = x
  end
  local y = Utils.getNoNil(getXMLFloat(xml, "Godzina.position#y"), Godzina.d.position.y)
  if (self:validateFloat(y, "y")) then
    self.rendering.y = y
  end
  local color = Utils.getNoNil(getXMLString(xml, "Godzina.rendering#color"), Godzina.d.rendering.color)

  if color:lower() ~= "white" and color:lower() ~= "black" then
    local c = Utils.splitString(",", color)
    if table.getn(c) == 4 then
      local valid = true
      for _, v in pairs(c) do
        if not self:validateFloat(v, "color") then
          valid = false
          break
        end
      end
      if valid then
        self.rendering.color = color
      else
        self.rendering.color = Godzina.d.rendering.color
      end
    else
      self.debugger:warn(function()
        return "Invalid value for color, only 'white', 'black' or a custom color like '0,0.5,1,0.8' allowed, found " .. color
      end)
      self.rendering.color = Godzina.d.rendering.color
    end
  else
    self.rendering.color = color
  end

  local fontSize = Utils.getNoNil(getXMLFloat(xml, "Godzina.rendering#fontSize"), Godzina.d.rendering.fontSize)
  if self:validateFloat(fontSize, "fontSize") then
    self.rendering.fontSize = fontSize;
  end
  self.timeFormat = Utils.getNoNil(getXMLString(xml, "Godzina.format#string"), Godzina.d.timeFormat)
  delete(xml)
end

function Godzina:validateFloat(float, text)
  local f = tonumber(float)
  if f ~= nil and f >= 0 and f <= 1 then
    return true
  else
    self.debugger:warn(function()
      return "Invalid value for " .. text .. ", must be a value between 0 and 1 including both, was " .. float
    end)
    return false
  end
end

addModEventListener(Godzina)