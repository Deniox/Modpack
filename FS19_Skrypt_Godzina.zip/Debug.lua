Debug = {}
Debug.__index = Debug

Debug.TRACE = 1
Debug.DEBUG = 2
Debug.INFO = 3
Debug.WARNING = 4
Debug.ERROR = 5
Debug.OFF = 6

function Debug:create(name, id)
  local d = {}
  setmetatable(d, Debug)
  d.name = name
  d.id = id
  d.lvl = Debug.DEBUG
  return d
end

function Debug:setLogLvl(lvl)
  self.lvl = lvl
end

function Debug:trace(txt)
  self:print(Debug.TRACE, txt)
end

function Debug:debug(txt)
  self:print(Debug.DEBUG, txt)
end

function Debug:info(txt)
  self:print(Debug.INFO, txt)
end

function Debug:warn(txt)
  self:print(Debug.WARNING, txt)
end

function Debug:error(txt)
  self:print(Debug.ERROR, txt)
end

function Debug:print(lvl, txt)
  if lvl < self.lvl then
    return
  end
  local level = "TRACE"
  if lvl == Debug.ERROR then
    level = "ERROR"
  elseif lvl == Debug.WARNING then
    level = "WARN"
  elseif lvl == Debug.INFO then
    level = "INFO"
  elseif lvl == Debug.DEBUG then
    level = "DEBUG"
  end

  local text
  if type(txt) == "function" then
    text = txt()
  else
    text = txt
  end

  if (self.id == nil) then
    print(self.name .. " - " .. level .. ": " .. text)
  else
    print(self.name .. " - " .. level .. ": (" .. id .. " - " .. getName(id) .. ") " .. text)
  end
end